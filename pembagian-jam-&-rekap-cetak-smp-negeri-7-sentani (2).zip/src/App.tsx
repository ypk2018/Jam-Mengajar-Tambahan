/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import Sidebar from './components/Sidebar';
import Dashboard from './components/Dashboard';
import GuruManager from './components/GuruManager';
import MapelManager from './components/MapelManager';
import KelasManager from './components/KelasManager';
import PembagianJamManager from './components/PembagianJamManager';
import TugasTambahanManager from './components/TugasTambahanManager';
import RekapCetak from './components/RekapCetak';
import BackupSyncManager from './components/BackupSyncManager';

import { 
  Teacher, 
  Subject, 
  ClassRoom, 
  TeachingAssignment, 
  AdditionalTask, 
  AcademicSettings 
} from './types';

import {
  DEFAULT_TEACHERS,
  DEFAULT_SUBJECTS,
  DEFAULT_CLASSES,
  DEFAULT_ASSIGNMENTS,
  DEFAULT_ADDITIONAL_TASKS,
  DEFAULT_SETTINGS,
  getStoredData,
  setStoredData,
  resetToDefaults
} from './data/seedData';

export default function App() {
  const [activeTab, setActiveTab] = useState<string>('dashboard');

  // Academic settings state
  const [academicSettings, setAcademicSettings] = useState<AcademicSettings>(() => 
    getStoredData('settings', DEFAULT_SETTINGS)
  );

  // Entities state
  const [teachers, setTeachers] = useState<Teacher[]>(() => 
    getStoredData('teachers', DEFAULT_TEACHERS)
  );
  const [subjects, setSubjects] = useState<Subject[]>(() => 
    getStoredData('subjects', DEFAULT_SUBJECTS)
  );
  const [classes, setClasses] = useState<ClassRoom[]>(() => 
    getStoredData('classes', DEFAULT_CLASSES)
  );
  const [assignments, setAssignments] = useState<TeachingAssignment[]>(() => 
    getStoredData('assignments', DEFAULT_ASSIGNMENTS)
  );
  const [additionalTasks, setAdditionalTasks] = useState<AdditionalTask[]>(() => 
    getStoredData('tasks', DEFAULT_ADDITIONAL_TASKS)
  );

  // Sync to local storage on change
  useEffect(() => {
    setStoredData('settings', academicSettings);
  }, [academicSettings]);

  useEffect(() => {
    setStoredData('teachers', teachers);
  }, [teachers]);

  useEffect(() => {
    setStoredData('subjects', subjects);
  }, [subjects]);

  useEffect(() => {
    setStoredData('classes', classes);
  }, [classes]);

  useEffect(() => {
    setStoredData('assignments', assignments);
  }, [assignments]);

  useEffect(() => {
    setStoredData('tasks', additionalTasks);
  }, [additionalTasks]);

  // Helper to decode Base64 data from URL
  const decodeData = (encoded: string): any => {
    try {
      const binString = atob(encoded);
      const len = binString.length;
      const bytes = new Uint8Array(len);
      for (let i = 0; i < len; i++) {
        bytes[i] = binString.charCodeAt(i);
      }
      const jsonStr = new TextDecoder().decode(bytes);
      return JSON.parse(jsonStr);
    } catch (e) {
      console.error('Gagal mendekode data URL', e);
      return null;
    }
  };

  // Helper to decompress data payload from shortened URL
  const decompressPayload = (c: any): any => {
    if (!c) return null;
    // If it is already in uncompressed format (backward compatibility)
    if (c.teachers || c.subjects) return c;

    const defaultYear = c.s?.y || '';
    return {
      settings: c.s ? {
        academic_year: c.s.y,
        semester: c.s.m
      } : undefined,
      teachers: c.t?.map((x: any) => ({
        id: x.i,
        name: x.n,
        nip: x.p || undefined,
        golongan: x.g,
        status: x.s,
        bidang_studi: x.b
      })),
      subjects: c.u?.map((x: any) => ({
        id: x.i,
        name: x.n,
        code: x.c,
        kelompok: x.k
      })),
      classes: c.c?.map((x: any) => ({
        id: x.i,
        name: x.n,
        tingkat: x.t
      })),
      assignments: c.a?.map((x: any) => ({
        id: x.i,
        teacher_id: x.t,
        subject_id: x.s,
        class_id: x.c,
        hours_per_week: x.h,
        academic_year: x.y || defaultYear
      })),
      tasks: c.k?.map((x: any) => ({
        id: x.i,
        teacher_id: x.t,
        task_name: x.n,
        hours_equivalent: x.h,
        task_description: x.d || undefined,
        academic_year: x.y || defaultYear
      }))
    };
  };

  // Check URL parameters on mount
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const encodedData = params.get('data') || params.get('import_data');
    if (encodedData) {
      try {
        let decoded = decodeData(encodedData);
        if (decoded) {
          decoded = decompressPayload(decoded);
        }
        if (decoded && (decoded.teachers || decoded.subjects)) {
          setTimeout(() => {
            const confirmMsg = `Tautan memuat data jadwal/guru SMP Negeri 7 Sentani yang dibagikan.\n\n` +
              `Tahun Pelajaran: ${decoded.settings?.academic_year || '-'}\n` +
              `Semester: ${decoded.settings?.semester || '-'}\n` +
              `Jumlah Guru: ${decoded.teachers?.length || 0} orang\n\n` +
              `Apakah Anda ingin mengimpor data ini dan mengganti data aktif di browser Anda saat ini?`;
              
            if (window.confirm(confirmMsg)) {
              if (decoded.settings) setAcademicSettings(decoded.settings);
              if (decoded.teachers) setTeachers(decoded.teachers);
              if (decoded.subjects) setSubjects(decoded.subjects);
              if (decoded.classes) setClasses(decoded.classes);
              if (decoded.assignments) setAssignments(decoded.assignments);
              if (decoded.tasks) setAdditionalTasks(decoded.tasks);
              
              if (decoded.logoPemda) localStorage.setItem('logo_pemda', decoded.logoPemda);
              if (decoded.logoSekolah) localStorage.setItem('logo_sekolah', decoded.logoSekolah);
              
              alert('Sukses! Seluruh data dari tautan berhasil diimpor dan disimpan otomatis pada browser perangkat Anda.');
              
              // Clean URL query parameters
              window.history.replaceState({}, document.title, window.location.pathname);
            } else {
              window.history.replaceState({}, document.title, window.location.pathname);
            }
          }, 600);
        }
      } catch (err) {
        console.error('Error during URL data import', err);
      }
    }
  }, []);

  // Reset functionality
  const handleReset = () => {
    resetToDefaults();
    setAcademicSettings(DEFAULT_SETTINGS);
    setTeachers(DEFAULT_TEACHERS);
    setSubjects(DEFAULT_SUBJECTS);
    setClasses(DEFAULT_CLASSES);
    setAssignments(DEFAULT_ASSIGNMENTS);
    setAdditionalTasks(DEFAULT_ADDITIONAL_TASKS);
    setActiveTab('dashboard');
  };

  // ================= CRUD: TEACHERS =================
  const handleAddTeacher = (teacher: Teacher) => {
    setTeachers([...teachers, teacher]);
  };

  const handleUpdateTeacher = (updated: Teacher) => {
    setTeachers(teachers.map(t => t.id === updated.id ? updated : t));
  };

  const handleDeleteTeacher = (id: string) => {
    // Delete the teacher
    setTeachers(teachers.filter(t => t.id !== id));
    // Clean up related assignments
    setAssignments(assignments.filter(a => a.teacher_id !== id));
    // Clean up related additional tasks
    setAdditionalTasks(additionalTasks.filter(t => t.teacher_id !== id));
    // Clean up homeroom role if applicable
    setClasses(classes.map(c => c.wali_kelas_id === id ? { ...c, wali_kelas_id: undefined } : c));
  };

  const handleBulkImport = (
    newTeachers: Teacher[],
    newAssignments: TeachingAssignment[],
    newTasks: AdditionalTask[],
    newSubjects?: Subject[],
    newClasses?: ClassRoom[]
  ) => {
    setTeachers(prev => [...prev, ...newTeachers]);
    setAssignments(prev => [...prev, ...newAssignments]);
    setAdditionalTasks(prev => [...prev, ...newTasks]);
    if (newSubjects && newSubjects.length > 0) {
      setSubjects(prev => [...prev, ...newSubjects]);
    }
    if (newClasses && newClasses.length > 0) {
      setClasses(prev => [...prev, ...newClasses]);
    }
  };

  const handleSyncTeacherAssignmentsAndTasks = (
    teacherId: string,
    newAssignments: TeachingAssignment[],
    newTasks: AdditionalTask[]
  ) => {
    setAssignments(prev => [
      ...prev.filter(a => a.teacher_id !== teacherId),
      ...newAssignments
    ]);
    setAdditionalTasks(prev => [
      ...prev.filter(t => t.teacher_id !== teacherId),
      ...newTasks
    ]);
  };

  // ================= CRUD: SUBJECTS =================
  const handleAddSubject = (subject: Subject) => {
    setSubjects([...subjects, subject]);
  };

  const handleUpdateSubject = (updated: Subject) => {
    setSubjects(subjects.map(s => s.id === updated.id ? updated : s));
  };

  const handleDeleteSubject = (id: string) => {
    setSubjects(subjects.filter(s => s.id !== id));
    // Clean up related teaching assignments
    setAssignments(assignments.filter(a => a.subject_id !== id));
  };

  // ================= CRUD: CLASSES =================
  const handleAddClass = (classRoom: ClassRoom) => {
    setClasses([...classes, classRoom]);
  };

  const handleUpdateClass = (updated: ClassRoom) => {
    setClasses(classes.map(c => c.id === updated.id ? updated : c));
  };

  const handleDeleteClass = (id: string) => {
    setClasses(classes.filter(c => c.id !== id));
    // Clean up related assignments
    setAssignments(assignments.filter(a => a.class_id !== id));
  };

  // ================= CRUD: ASSIGNMENTS =================
  const handleAddAssignment = (assignment: TeachingAssignment) => {
    setAssignments([...assignments, assignment]);
  };

  const handleUpdateAssignment = (updated: TeachingAssignment) => {
    setAssignments(assignments.map(a => a.id === updated.id ? updated : a));
  };

  const handleDeleteAssignment = (id: string) => {
    setAssignments(assignments.filter(a => a.id !== id));
  };

  // ================= CRUD: ADDITIONAL TASKS =================
  const handleAddTask = (task: AdditionalTask) => {
    setAdditionalTasks([...additionalTasks, task]);
  };

  const handleUpdateTask = (updated: AdditionalTask) => {
    setAdditionalTasks(additionalTasks.map(t => t.id === updated.id ? updated : t));
  };

  const handleDeleteTask = (id: string) => {
    setAdditionalTasks(additionalTasks.filter(t => t.id !== id));
  };

  // Render correct panel
  const renderContent = () => {
    switch (activeTab) {
      case 'dashboard':
        return (
          <Dashboard 
            teachers={teachers}
            subjects={subjects}
            classes={classes}
            assignments={assignments}
            additionalTasks={additionalTasks}
            academicSettings={academicSettings}
          />
        );
      case 'guru':
        return (
          <GuruManager 
            teachers={teachers}
            subjects={subjects}
            classes={classes}
            assignments={assignments}
            additionalTasks={additionalTasks}
            academicSettings={academicSettings}
            onAddTeacher={handleAddTeacher}
            onUpdateTeacher={handleUpdateTeacher}
            onDeleteTeacher={handleDeleteTeacher}
            onBulkImport={handleBulkImport}
            onSyncAssignmentsAndTasks={handleSyncTeacherAssignmentsAndTasks}
          />
        );
      case 'mapel':
        return (
          <MapelManager 
            subjects={subjects}
            onAddSubject={handleAddSubject}
            onUpdateSubject={handleUpdateSubject}
            onDeleteSubject={handleDeleteSubject}
          />
        );
      case 'kelas':
        return (
          <KelasManager 
            classes={classes}
            teachers={teachers}
            onAddClass={handleAddClass}
            onUpdateClass={handleUpdateClass}
            onDeleteClass={handleDeleteClass}
          />
        );
      case 'pembagian':
        return (
          <PembagianJamManager 
            assignments={assignments}
            teachers={teachers}
            subjects={subjects}
            classes={classes}
            academicSettings={academicSettings}
            onAddAssignment={handleAddAssignment}
            onUpdateAssignment={handleUpdateAssignment}
            onDeleteAssignment={handleDeleteAssignment}
          />
        );
      case 'tugas':
        return (
          <TugasTambahanManager 
            additionalTasks={additionalTasks}
            teachers={teachers}
            academicSettings={academicSettings}
            onAddTask={handleAddTask}
            onUpdateTask={handleUpdateTask}
            onDeleteTask={handleDeleteTask}
          />
        );
      case 'rekap':
        return (
          <RekapCetak 
            teachers={teachers}
            subjects={subjects}
            classes={classes}
            assignments={assignments}
            additionalTasks={additionalTasks}
            academicSettings={academicSettings}
          />
        );
      case 'sync':
        return (
          <BackupSyncManager 
            teachers={teachers}
            subjects={subjects}
            classes={classes}
            assignments={assignments}
            additionalTasks={additionalTasks}
            academicSettings={academicSettings}
            onImportAll={(imported) => {
              if (imported.settings) setAcademicSettings(imported.settings);
              if (imported.teachers) setTeachers(imported.teachers);
              if (imported.subjects) setSubjects(imported.subjects);
              if (imported.classes) setClasses(imported.classes);
              if (imported.assignments) setAssignments(imported.assignments);
              if (imported.tasks) setAdditionalTasks(imported.tasks);
              
              if (imported.logoPemda !== undefined) {
                if (imported.logoPemda === null) localStorage.removeItem('logo_pemda');
                else localStorage.setItem('logo_pemda', imported.logoPemda);
              }
              if (imported.logoSekolah !== undefined) {
                if (imported.logoSekolah === null) localStorage.removeItem('logo_sekolah');
                else localStorage.setItem('logo_sekolah', imported.logoSekolah);
              }
            }}
          />
        );
      default:
        return <div>Dashboard Placeholder</div>;
    }
  };

  return (
    <div id="main-app" className="min-h-screen bg-slate-50/50">
      {/* Fixed Sidebar */}
      <Sidebar 
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        academicSettings={academicSettings}
        setAcademicSettings={setAcademicSettings}
        onResetToDefaults={handleReset}
      />

      {/* Main Content Area */}
      <main id="app-content-panel" className="pl-80 min-h-screen transition-all duration-200 print:pl-0">
        <div className="max-w-7xl mx-auto p-8 md:p-10 print:p-0">
          {renderContent()}
        </div>
      </main>
    </div>
  );
}
