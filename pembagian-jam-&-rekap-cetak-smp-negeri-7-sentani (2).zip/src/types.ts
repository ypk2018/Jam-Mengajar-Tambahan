/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type TeacherStatus = 'PNS' | 'PPPK' | 'Honorer';
export type CurriculumType = 'Kurikulum Merdeka' | 'K13';
export type GradeLevel = 'VII' | 'VIII' | 'IX';
export type SemesterType = 'Ganjil' | 'Genap';

export interface Teacher {
  id: string;
  name: string;
  nip: string; // Employee number (optional, empty string if none)
  golongan: string; // e.g. "IV/a", "III/c", or "-"
  status: TeacherStatus;
  bidang_studi: string; // e.g. "Matematika", "Bahasa Indonesia"
}

export interface Subject {
  id: string;
  code: string; // e.g. "MAT-01"
  name: string; // e.g. "Matematika"
  kurikulum: CurriculumType;
}

export interface ClassRoom {
  id: string;
  name: string; // e.g. "Kelas VII-A"
  tingkat: GradeLevel;
  wali_kelas_id?: string; // Teacher ID of the homeroom teacher
}

export interface TeachingAssignment {
  id: string;
  teacher_id: string;
  subject_id: string;
  class_id: string;
  hours_per_week: number;
  academic_year: string; // e.g. "2025/2026"
  semester: SemesterType;
}

export interface AdditionalTask {
  id: string;
  teacher_id: string;
  task_name: string; // e.g. "Kepala Sekolah", "Wakil Kepala Sekolah", "Kepala Perpustakaan", "Wali Kelas VII-A"
  hours_equivalent: number; // e.g. 12, 6, 2 hours
  task_description?: string;
  academic_year: string;
}

export interface AcademicSettings {
  academic_year: string; // e.g. "2025/2026"
  semester: SemesterType;
}
