/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Teacher, Subject, ClassRoom, TeachingAssignment, AdditionalTask, AcademicSettings } from '../types';

export const DEFAULT_TEACHERS: Teacher[] = [
  { id: 't1', name: 'Drs. Yohanis Wally, M.Pd', nip: '196805121994031008', golongan: 'IV/b', status: 'PNS', bidang_studi: 'Bahasa Indonesia' },
  { id: 't2', name: 'Mariana Ondikeleuw, S.Pd', nip: '197509182005012011', golongan: 'IV/a', status: 'PNS', bidang_studi: 'Matematika' }
];

export const DEFAULT_SUBJECTS: Subject[] = [
  { id: 's1', code: 'IND-01', name: 'Bahasa Indonesia', kurikulum: 'Kurikulum Merdeka' },
  { id: 's2', code: 'MAT-02', name: 'Matematika', kurikulum: 'Kurikulum Merdeka' }
];

export const DEFAULT_CLASSES: ClassRoom[] = [
  { id: 'c1', name: 'Kelas VII-A', tingkat: 'VII', wali_kelas_id: 't1' },
  { id: 'c2', name: 'Kelas VIII-A', tingkat: 'VIII', wali_kelas_id: 't2' }
];

export const DEFAULT_SETTINGS: AcademicSettings = {
  academic_year: '2025/2026',
  semester: 'Ganjil'
};

export const DEFAULT_ASSIGNMENTS: TeachingAssignment[] = [
  { id: 'a1', teacher_id: 't1', subject_id: 's1', class_id: 'c1', hours_per_week: 6, academic_year: '2025/2026', semester: 'Ganjil' },
  { id: 'a2', teacher_id: 't2', subject_id: 's2', class_id: 'c2', hours_per_week: 5, academic_year: '2025/2026', semester: 'Ganjil' }
];

export const DEFAULT_ADDITIONAL_TASKS: AdditionalTask[] = [
  { id: 'at1', teacher_id: 't1', task_name: 'Kepala Sekolah', hours_equivalent: 12, task_description: 'Penanggung jawab utama seluruh kegiatan akademik dan non-akademik sekolah.', academic_year: '2025/2026' },
  { id: 'at2', teacher_id: 't2', task_name: 'Wakil Kepala Sekolah Bidang Kurikulum', hours_equivalent: 12, task_description: 'Penyusunan jadwal pelajaran, pembagian tugas mengajar, dan rekapitulasi KBM.', academic_year: '2025/2026' }
];

// Helper to load items from LocalStorage with custom fallback
export function getStoredData<T>(key: string, defaultValue: T): T {
  try {
    const item = localStorage.getItem(`smp7_${key}`);
    return item ? JSON.parse(item) : defaultValue;
  } catch (error) {
    console.error('Error reading localStorage key', key, error);
    return defaultValue;
  }
}

// Helper to save items to LocalStorage
export function setStoredData<T>(key: string, value: T): void {
  try {
    localStorage.setItem(`smp7_${key}`, JSON.stringify(value));
  } catch (error) {
    console.error('Error writing localStorage key', key, error);
  }
}

export function resetToDefaults(): void {
  try {
    localStorage.removeItem('smp7_teachers');
    localStorage.removeItem('smp7_subjects');
    localStorage.removeItem('smp7_classes');
    localStorage.removeItem('smp7_assignments');
    localStorage.removeItem('smp7_tasks');
    localStorage.removeItem('smp7_settings');
  } catch (e) {
    console.error(e);
  }
}
