/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  Plus, 
  Edit, 
  Trash2, 
  X, 
  School, 
  Award,
  GraduationCap
} from 'lucide-react';
import { ClassRoom, Teacher, GradeLevel } from '../types';

interface KelasManagerProps {
  classes: ClassRoom[];
  teachers: Teacher[];
  onAddClass: (classRoom: ClassRoom) => void;
  onUpdateClass: (classRoom: ClassRoom) => void;
  onDeleteClass: (id: string) => void;
}

const EMPTY_CLASS: Omit<ClassRoom, 'id'> = {
  name: '',
  tingkat: 'VII',
  wali_kelas_id: ''
};

export default function KelasManager({
  classes,
  teachers,
  onAddClass,
  onUpdateClass,
  onDeleteClass
}: KelasManagerProps) {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [filterTingkat, setFilterTingkat] = useState<string>('all');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  
  // Form state
  const [formData, setFormData] = useState<Omit<ClassRoom, 'id'>>(EMPTY_CLASS);

  // Filtered classes
  const filteredClasses = classes.filter(c => {
    return filterTingkat === 'all' ? true : c.tingkat === filterTingkat;
  }).sort((a, b) => a.name.localeCompare(b.name));

  const openAddModal = () => {
    setEditingId(null);
    setErrorMsg(null);
    setFormData(EMPTY_CLASS);
    setIsModalOpen(true);
  };

  const openEditModal = (classRoom: ClassRoom) => {
    setEditingId(classRoom.id);
    setErrorMsg(null);
    setFormData({
      name: classRoom.name,
      tingkat: classRoom.tingkat,
      wali_kelas_id: classRoom.wali_kelas_id || ''
    });
    setIsModalOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanName = formData.name.trim();

    if (!cleanName) {
      setErrorMsg('Nama Kelas tidak boleh kosong.');
      return;
    }

    // Check duplicate classroom name
    const isDuplicateName = classes.some(
      c => c.name.toLowerCase() === cleanName.toLowerCase() && c.id !== editingId
    );
    if (isDuplicateName) {
      setErrorMsg(`Kelas dengan nama "${cleanName}" sudah terdaftar.`);
      return;
    }

    // Check duplicate Wali Kelas assignment
    if (formData.wali_kelas_id) {
      const isWaliKelasElsewhere = classes.some(
        c => c.wali_kelas_id === formData.wali_kelas_id && c.id !== editingId
      );
      if (isWaliKelasElsewhere) {
        const assignedClass = classes.find(c => c.wali_kelas_id === formData.wali_kelas_id);
        const teacherName = teachers.find(t => t.id === formData.wali_kelas_id)?.name || 'Guru';
        setErrorMsg(`Gagal: ${teacherName} sudah ditugaskan sebagai Wali Kelas di ${assignedClass?.name}.`);
        return;
      }
    }

    if (editingId) {
      onUpdateClass({
        id: editingId,
        name: cleanName,
        tingkat: formData.tingkat,
        wali_kelas_id: formData.wali_kelas_id || undefined
      });
    } else {
      onAddClass({
        id: 'class_' + Date.now().toString(),
        name: cleanName,
        tingkat: formData.tingkat,
        wali_kelas_id: formData.wali_kelas_id || undefined
      });
    }
    setIsModalOpen(false);
  };

  const handleDelete = (id: string, name: string) => {
    if (window.confirm(`Apakah Anda yakin ingin menghapus kelas "${name}"? Tindakan ini juga akan menghapus pembagian jam mengajar pada kelas ini.`)) {
      onDeleteClass(id);
    }
  };

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-display font-bold text-3xl text-slate-950 tracking-tight">Manajemen Data Kelas</h1>
          <p className="text-slate-500 text-sm mt-1">Daftar rombongan belajar (VII, VIII, IX) beserta penugasan Wali Kelas.</p>
        </div>
        <button
          id="btn-add-class"
          onClick={openAddModal}
          className="bg-blue-600 hover:bg-blue-700 text-white font-semibold px-4 py-2.5 rounded-xl shadow-lg shadow-blue-500/15 flex items-center justify-center space-x-2 transition duration-200 shrink-0 text-sm"
        >
          <School size={18} className="stroke-[2.5]" />
          <span>Tambah Kelas Baru</span>
        </button>
      </div>

      {/* Filter Options */}
      <div className="bg-white p-4 rounded-xl shadow-xs border border-slate-200 flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Tingkatan:</span>
          <div className="flex bg-slate-100 p-1 rounded-xl border border-slate-200">
            {['all', 'VII', 'VIII', 'IX'].map((lvl) => (
              <button
                key={lvl}
                type="button"
                onClick={() => setFilterTingkat(lvl)}
                className={`px-4 py-1 text-xs font-medium rounded-lg transition ${
                  filterTingkat === lvl 
                    ? 'bg-white text-slate-900 shadow-sm font-semibold' 
                    : 'text-slate-500 hover:text-slate-900'
                }`}
              >
                {lvl === 'all' ? 'Semua Tingkat' : `Tingkat ${lvl}`}
              </button>
            ))}
          </div>
        </div>
        <div className="text-xs font-semibold text-slate-500">
          Total: {filteredClasses.length} Kelas Rombel
        </div>
      </div>

      {/* Classes Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredClasses.length > 0 ? (
          filteredClasses.map((cl) => {
            const wali = teachers.find(t => t.id === cl.wali_kelas_id);
            return (
              <div 
                key={cl.id} 
                className="bg-white rounded-xl shadow-xs border border-slate-200 overflow-hidden hover:shadow-md transition duration-200 flex flex-col justify-between"
              >
                {/* Visual Banner */}
                <div className="h-2 bg-blue-600" />
                
                <div className="p-5 flex-1 space-y-4">
                  {/* Title and Badge */}
                  <div className="flex items-center justify-between">
                    <h3 className="font-display font-bold text-xl text-slate-950">
                      {cl.name}
                    </h3>
                    <span className="bg-blue-50 text-blue-700 font-bold px-2.5 py-0.5 rounded border border-blue-100 text-[11px]">
                      Tingkat {cl.tingkat}
                    </span>
                  </div>

                  {/* Wali Kelas detail */}
                  <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-100 flex items-start space-x-3">
                    <div className="bg-slate-200/80 p-1.5 rounded-lg text-slate-600 shrink-0 mt-0.5">
                      <Award size={16} />
                    </div>
                    <div>
                      <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider block">Wali Kelas</span>
                      <p className="font-semibold text-slate-800 text-xs mt-0.5">
                        {wali ? wali.name : 'Belum Ditugaskan'}
                      </p>
                      {wali && (
                        <span className="text-[10px] text-slate-400 font-medium font-mono">{wali.nip ? `NIP: ${wali.nip}` : 'PNS'}</span>
                      )}
                    </div>
                  </div>
                </div>

                {/* Card Actions */}
                <div className="px-5 py-3.5 bg-slate-50/50 border-t border-slate-100 flex justify-end space-x-1">
                  <button
                    onClick={() => openEditModal(cl)}
                    className="p-1.5 hover:bg-slate-100 rounded-lg text-slate-500 hover:text-slate-900 transition text-xs flex items-center space-x-1 font-medium"
                  >
                    <Edit size={14} />
                    <span>Edit</span>
                  </button>
                  <button
                    onClick={() => handleDelete(cl.id, cl.name)}
                    className="p-1.5 hover:bg-red-50 rounded-lg text-slate-400 hover:text-red-500 transition text-xs flex items-center space-x-1 font-medium"
                  >
                    <Trash2 size={14} />
                    <span>Hapus</span>
                  </button>
                </div>
              </div>
            );
          })
        ) : (
          <div className="col-span-full py-12 text-center text-slate-400 font-medium">
            Tidak ada kelas rombongan belajar yang tersedia.
          </div>
        )}
      </div>

      {/* Form Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-slate-950/40 backdrop-blur-xs flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl w-full max-w-md shadow-2xl border border-slate-100 overflow-hidden animate-zoom-in">
            {/* Modal Header */}
            <div className="px-6 py-5 border-b border-slate-100 flex justify-between items-center bg-slate-50">
              <h2 className="font-display font-bold text-lg text-slate-900">
                {editingId ? 'Edit Data Kelas' : 'Tambah Kelas Baru'}
              </h2>
              <button 
                onClick={() => setIsModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 hover:bg-slate-200/50 p-1.5 rounded-lg transition"
              >
                <X size={18} />
              </button>
            </div>

            {/* Modal Body / Form */}
            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              {/* Error Message */}
              {errorMsg && (
                <div className="bg-red-50 text-red-700 text-xs p-3.5 rounded-xl border border-red-100 flex items-center justify-between font-medium">
                  <span>{errorMsg}</span>
                  <button 
                    type="button" 
                    onClick={() => setErrorMsg(null)}
                    className="text-red-400 hover:text-red-600 transition p-1 rounded"
                  >
                    <X size={14} className="stroke-[2.5]" />
                  </button>
                </div>
              )}

              {/* Nama Kelas */}
              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1.5">Nama Rombel / Kelas</label>
                <input
                  type="text"
                  required
                  placeholder="Contoh: Kelas VII-A atau Kelas IX-B"
                  value={formData.name}
                  onChange={(e) => setFormData({...formData, name: e.target.value})}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 text-sm text-slate-800 focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500 transition"
                />
              </div>

              {/* Tingkat Kelas */}
              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1.5">Tingkatan Rombel</label>
                <select
                  value={formData.tingkat}
                  onChange={(e) => setFormData({...formData, tingkat: e.target.value as GradeLevel})}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2.5 text-sm text-slate-800 focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500 transition font-medium"
                >
                  <option value="VII">VII (Tujuh)</option>
                  <option value="VIII">VIII (Delapan)</option>
                  <option value="IX">IX (Sembilan)</option>
                </select>
              </div>

              {/* Wali Kelas */}
              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1.5">Wali Kelas Penanggung Jawab</label>
                <select
                  value={formData.wali_kelas_id}
                  onChange={(e) => setFormData({...formData, wali_kelas_id: e.target.value})}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2.5 text-sm text-slate-800 focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500 transition font-medium text-slate-800"
                >
                  <option value="">-- Tanpa Wali Kelas --</option>
                  {teachers.map((teacher) => (
                    <option key={teacher.id} value={teacher.id}>
                      {teacher.name} ({teacher.status})
                    </option>
                  ))}
                </select>
              </div>

              {/* Modal Footer Buttons */}
              <div className="pt-4 border-t border-slate-100 flex justify-end space-x-2.5">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 rounded-xl text-xs font-semibold text-slate-600 transition"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-blue-600 hover:bg-blue-700 rounded-xl text-xs font-bold text-white shadow-md shadow-blue-600/10 transition"
                >
                  {editingId ? 'Simpan Perubahan' : 'Simpan Kelas'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
