/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  Plus, 
  Edit, 
  Trash2, 
  X, 
  ClipboardList, 
  Clock,
  Briefcase
} from 'lucide-react';
import { AdditionalTask, Teacher, AcademicSettings } from '../types';

interface TugasTambahanManagerProps {
  additionalTasks: AdditionalTask[];
  teachers: Teacher[];
  academicSettings: AcademicSettings;
  onAddTask: (task: AdditionalTask) => void;
  onUpdateTask: (task: AdditionalTask) => void;
  onDeleteTask: (id: string) => void;
}

const EMPTY_TASK = {
  teacher_id: '',
  task_name: '',
  hours_equivalent: 6,
  task_description: ''
};

export default function TugasTambahanManager({
  additionalTasks,
  teachers,
  academicSettings,
  onAddTask,
  onUpdateTask,
  onDeleteTask
}: TugasTambahanManagerProps) {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);

  // Form state
  const [formData, setFormData] = useState(EMPTY_TASK);

  // Filter tasks for current academic year
  const currentTasks = additionalTasks.filter(
    t => t.academic_year === academicSettings.academic_year
  );

  const openAddModal = () => {
    setEditingId(null);
    setFormData({
      teacher_id: teachers[0]?.id || '',
      task_name: '',
      hours_equivalent: 6,
      task_description: ''
    });
    setIsModalOpen(true);
  };

  const openEditModal = (task: AdditionalTask) => {
    setEditingId(task.id);
    setFormData({
      teacher_id: task.teacher_id,
      task_name: task.task_name,
      hours_equivalent: task.hours_equivalent,
      task_description: task.task_description || ''
    });
    setIsModalOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.teacher_id || !formData.task_name.trim()) return;

    if (editingId) {
      onUpdateTask({
        id: editingId,
        ...formData,
        academic_year: academicSettings.academic_year
      });
    } else {
      onAddTask({
        id: 'task_' + Date.now().toString(),
        ...formData,
        academic_year: academicSettings.academic_year
      });
    }
    setIsModalOpen(false);
  };

  const handleDelete = (id: string, teacherName: string, taskName: string) => {
    if (window.confirm(`Apakah Anda yakin ingin menghapus tugas tambahan "${taskName}" untuk guru "${teacherName}"?`)) {
      onDeleteTask(id);
    }
  };

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-display font-bold text-3xl text-slate-950 tracking-tight">Tugas Tambahan Guru</h1>
          <p className="text-slate-500 text-sm mt-1">Daftar guru yang memegang jabatan fungsional tambahan beserta ekuivalensi jam mengajar.</p>
          <div className="inline-flex items-center space-x-2 mt-2 bg-blue-50 text-blue-700 px-3 py-1 rounded-lg border border-blue-100 text-xs font-semibold">
            <span>Aktif: Tahun Pelajaran {academicSettings.academic_year}</span>
          </div>
        </div>
        <button
          id="btn-add-task"
          onClick={openAddModal}
          className="bg-blue-600 hover:bg-blue-700 text-white font-semibold px-4 py-2.5 rounded-xl shadow-lg shadow-blue-500/15 flex items-center justify-center space-x-2 transition duration-200 shrink-0 text-sm"
        >
          <Plus size={18} className="stroke-[2.5]" />
          <span>Tambah Tugas Tambahan</span>
        </button>
      </div>

      {/* Tasks List Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {currentTasks.length > 0 ? (
          currentTasks.map((task) => {
            const teacher = teachers.find(t => t.id === task.teacher_id);
            return (
              <div 
                key={task.id} 
                className="bg-white rounded-xl shadow-xs border border-slate-200 p-5 hover:shadow-md transition duration-200 flex flex-col justify-between"
              >
                <div className="space-y-4">
                  <div className="flex items-start justify-between">
                    <div className="flex items-center space-x-3">
                      <div className="bg-slate-100 text-slate-700 p-2.5 rounded-xl border border-slate-200">
                        <Briefcase size={20} className="stroke-[2]" />
                      </div>
                      <div>
                        <h3 className="font-bold text-slate-900 text-base leading-tight">
                          {task.task_name}
                        </h3>
                        <span className="text-[10px] text-slate-400 font-bold block mt-1 uppercase font-mono tracking-wider">Tugas Tambahan Fungsional</span>
                      </div>
                    </div>
                    
                    <span className="bg-blue-50 text-blue-700 font-bold px-2.5 py-1 rounded border border-blue-100 text-xs font-mono flex items-center space-x-1 shrink-0">
                      <Clock size={12} />
                      <span>{task.hours_equivalent} JP Ekuivalen</span>
                    </span>
                  </div>

                  <div className="pt-3 border-t border-slate-50">
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Pemegang Tugas:</span>
                    <p className="font-semibold text-slate-800 text-sm mt-0.5">
                      {teacher ? teacher.name : 'Unknown Teacher'}
                    </p>
                    {teacher && (
                      <span className="text-[10px] text-slate-400 font-semibold font-mono">{teacher.nip ? `NIP: ${teacher.nip}` : 'PNS'} ({teacher.status})</span>
                    )}
                  </div>

                  {task.task_description && (
                    <p className="text-xs text-slate-400 bg-slate-50/50 p-3 rounded-xl leading-relaxed border border-slate-100/50">
                      {task.task_description}
                    </p>
                  )}
                </div>

                <div className="mt-6 pt-4 border-t border-slate-50 flex justify-end space-x-2">
                  <button
                    onClick={() => openEditModal(task)}
                    className="p-1.5 hover:bg-slate-100 rounded-lg text-slate-500 hover:text-slate-900 transition text-xs flex items-center space-x-1 font-medium"
                  >
                    <Edit size={14} />
                    <span>Edit</span>
                  </button>
                  <button
                    onClick={() => handleDelete(task.id, teacher?.name || '', task.task_name)}
                    className="p-1.5 hover:bg-red-50 rounded-lg text-slate-400 hover:text-red-500 transition text-xs flex items-center space-x-1 font-medium"
                  >
                    <Trash2 size={14} />
                    <span>Hapus</span>
                  </button>
                </div>
              </div>
            );
          })
        ) : (
          <div className="col-span-full py-12 text-center text-slate-400 font-medium bg-white rounded-xl border border-slate-200">
            Tidak ada tugas tambahan guru yang terdaftar pada tahun ajaran ini.
          </div>
        )}
      </div>

      {/* Form Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-slate-950/40 backdrop-blur-xs flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl w-full max-w-lg shadow-2xl border border-slate-100 overflow-hidden animate-zoom-in">
            {/* Modal Header */}
            <div className="px-6 py-5 border-b border-slate-100 flex justify-between items-center bg-slate-50">
              <h2 className="font-display font-bold text-lg text-slate-900">
                {editingId ? 'Edit Data Tugas Tambahan' : 'Tugaskan Tugas Tambahan'}
              </h2>
              <button 
                onClick={() => setIsModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 hover:bg-slate-200/50 p-1.5 rounded-lg transition"
              >
                <X size={18} />
              </button>
            </div>

            {/* Modal Body / Form */}
            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              {/* Guru Selector */}
              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1.5">Pilih Penerima Tugas</label>
                <select
                  required
                  value={formData.teacher_id}
                  onChange={(e) => setFormData({...formData, teacher_id: e.target.value})}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2.5 text-sm text-slate-850 focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500 transition font-medium text-slate-800"
                >
                  <option value="" disabled>-- Pilih Guru --</option>
                  {teachers.map(t => (
                    <option key={t.id} value={t.id}>
                      {t.name} ({t.status})
                    </option>
                  ))}
                </select>
              </div>

              {/* Nama Tugas Tambahan */}
              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1.5">Nama Tugas Tambahan (Jabatan)</label>
                <input
                  type="text"
                  required
                  placeholder="Contoh: Wakil Kepala Sekolah Bidang Kurikulum"
                  value={formData.task_name}
                  onChange={(e) => setFormData({...formData, task_name: e.target.value})}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 text-sm text-slate-800 focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500 transition"
                />
              </div>

              {/* Equivalent Hours */}
              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1.5">Ekuivalensi Jam Pelajaran (JP)</label>
                <div className="flex items-center space-x-3">
                  <input
                    type="number"
                    min="0"
                    max="100"
                    required
                    value={formData.hours_equivalent}
                    onChange={(e) => setFormData({...formData, hours_equivalent: parseInt(e.target.value) || 0})}
                    className="w-24 bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 text-sm text-slate-800 font-bold font-mono focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500 transition text-center"
                  />
                  <span className="text-xs font-semibold text-slate-500 leading-tight">
                    JP Mengajar / Minggu (Ekuivalensi)<br/>
                    <span className="text-[10px] text-slate-400">Kepsek = 12 JP, Wakasek = 12 JP, Kalab/Kapustaka = 6 JP, Walas = 6 JP</span>
                  </span>
                </div>
              </div>

              {/* Description */}
              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1.5">Deskripsi Penugasan (Optional)</label>
                <textarea
                  rows={3}
                  placeholder="Deskripsikan peran fungsional atau lingkup kerja tugas ini..."
                  value={formData.task_description}
                  onChange={(e) => setFormData({...formData, task_description: e.target.value})}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 text-sm text-slate-800 focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500 transition resize-none"
                />
              </div>

              {/* Modal Footer Buttons */}
              <div className="pt-4 border-t border-slate-100 flex justify-end space-x-2.5">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 rounded-xl text-xs font-semibold text-slate-600 transition"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-blue-600 hover:bg-blue-700 rounded-xl text-xs font-bold text-white shadow-md shadow-blue-600/10 transition"
                >
                  {editingId ? 'Simpan Perubahan' : 'Tugaskan Tugas'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
