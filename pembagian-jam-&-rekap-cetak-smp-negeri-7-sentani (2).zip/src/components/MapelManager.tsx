/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  Plus, 
  Search, 
  Edit, 
  Trash2, 
  X, 
  BookOpen, 
  BookmarkPlus 
} from 'lucide-react';
import { Subject, CurriculumType } from '../types';

interface MapelManagerProps {
  subjects: Subject[];
  onAddSubject: (subject: Subject) => void;
  onUpdateSubject: (subject: Subject) => void;
  onDeleteSubject: (id: string) => void;
}

const EMPTY_SUBJECT: Omit<Subject, 'id'> = {
  code: '',
  name: '',
  kurikulum: 'Kurikulum Merdeka'
};

export default function MapelManager({
  subjects,
  onAddSubject,
  onUpdateSubject,
  onDeleteSubject
}: MapelManagerProps) {
  const [search, setSearch] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  
  // Form state
  const [formData, setFormData] = useState<Omit<Subject, 'id'>>(EMPTY_SUBJECT);

  // Filtered subjects
  const filteredSubjects = subjects.filter(s => 
    s.name.toLowerCase().includes(search.toLowerCase()) || 
    s.code.toLowerCase().includes(search.toLowerCase()) ||
    s.kurikulum.toLowerCase().includes(search.toLowerCase())
  );

  const openAddModal = () => {
    setEditingId(null);
    setErrorMsg(null);
    setFormData(EMPTY_SUBJECT);
    setIsModalOpen(true);
  };

  const openEditModal = (subject: Subject) => {
    setEditingId(subject.id);
    setErrorMsg(null);
    setFormData({
      code: subject.code,
      name: subject.name,
      kurikulum: subject.kurikulum
    });
    setIsModalOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanCode = formData.code.trim().toUpperCase();
    const cleanName = formData.name.trim();

    if (!cleanCode) {
      setErrorMsg('Kode Mata Pelajaran tidak boleh kosong.');
      return;
    }
    if (!cleanName) {
      setErrorMsg('Nama Mata Pelajaran tidak boleh kosong.');
      return;
    }

    // Check duplicate code
    const isDuplicateCode = subjects.some(
      s => s.code.toUpperCase() === cleanCode && s.id !== editingId
    );
    if (isDuplicateCode) {
      setErrorMsg(`Kode Mapel "${cleanCode}" sudah digunakan oleh mata pelajaran lain.`);
      return;
    }

    // Check duplicate name
    const isDuplicateName = subjects.some(
      s => s.name.toLowerCase() === cleanName.toLowerCase() && s.id !== editingId
    );
    if (isDuplicateName) {
      setErrorMsg(`Nama Mapel "${cleanName}" sudah terdaftar.`);
      return;
    }

    if (editingId) {
      onUpdateSubject({
        id: editingId,
        code: cleanCode,
        name: cleanName,
        kurikulum: formData.kurikulum
      });
    } else {
      onAddSubject({
        id: 'subject_' + Date.now().toString(),
        code: cleanCode,
        name: cleanName,
        kurikulum: formData.kurikulum
      });
    }
    setIsModalOpen(false);
  };

  const handleDelete = (id: string, name: string) => {
    if (window.confirm(`Apakah Anda yakin ingin menghapus mata pelajaran "${name}"? Tindakan ini juga akan menghapus pembagian jam pelajaran terkait.`)) {
      onDeleteSubject(id);
    }
  };

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-display font-bold text-3xl text-slate-950 tracking-tight">Manajemen Mata Pelajaran</h1>
          <p className="text-slate-500 text-sm mt-1">Daftar mata pelajaran kurikulum dan kode akademiknya di SMP Negeri 7 Sentani.</p>
        </div>
        <button
          id="btn-add-subject"
          onClick={openAddModal}
          className="bg-blue-600 hover:bg-blue-700 text-white font-semibold px-4 py-2.5 rounded-xl shadow-lg shadow-blue-500/15 flex items-center justify-center space-x-2 transition duration-200 shrink-0 text-sm"
        >
          <BookmarkPlus size={18} className="stroke-[2.5]" />
          <span>Tambah Mapel Baru</span>
        </button>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white p-4 rounded-xl shadow-xs border border-slate-200 flex gap-4 items-center justify-between">
        <div className="relative w-full max-w-md">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
          <input
            type="text"
            placeholder="Cari nama mata pelajaran, kode, atau kurikulum..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-11 pr-4 py-2 text-sm text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500 transition"
          />
        </div>
        <div className="text-xs text-slate-500 font-semibold">
          Menampilkan {filteredSubjects.length} Mata Pelajaran
        </div>
      </div>

      {/* Subjects Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredSubjects.length > 0 ? (
          filteredSubjects.map((sub) => (
            <div 
              key={sub.id} 
              className="bg-white p-5 rounded-xl shadow-xs border border-slate-200 flex flex-col justify-between hover:shadow-md transition duration-200"
            >
              <div>
                <div className="flex items-center justify-between">
                  <span className="font-mono text-xs font-bold bg-slate-100 text-slate-600 px-2.5 py-1 rounded-lg border border-slate-200/60">
                    {sub.code}
                  </span>
                  <span className={`px-2 py-0.5 rounded text-[10px] font-bold tracking-wider uppercase ${
                    sub.kurikulum === 'Kurikulum Merdeka' 
                      ? 'bg-green-50 text-green-700 border border-green-100' 
                      : 'bg-blue-50 text-blue-700 border border-blue-100'
                  }`}>
                    {sub.kurikulum === 'Kurikulum Merdeka' ? 'Merdeka' : 'K-13'}
                  </span>
                </div>
                <h3 className="font-display font-bold text-slate-900 mt-4 text-base leading-snug">
                  {sub.name}
                </h3>
              </div>

              <div className="mt-6 pt-4 border-t border-slate-50 flex justify-end space-x-1.5">
                <button
                  onClick={() => openEditModal(sub)}
                  className="p-1.5 hover:bg-slate-50 rounded-lg text-slate-500 hover:text-slate-900 transition text-xs flex items-center space-x-1 font-medium"
                >
                  <Edit size={14} />
                  <span>Edit</span>
                </button>
                <button
                  onClick={() => handleDelete(sub.id, sub.name)}
                  className="p-1.5 hover:bg-red-50 rounded-lg text-slate-400 hover:text-red-500 transition text-xs flex items-center space-x-1 font-medium"
                >
                  <Trash2 size={14} />
                  <span>Hapus</span>
                </button>
              </div>
            </div>
          ))
        ) : (
          <div className="col-span-full py-12 text-center text-slate-400 font-medium">
            Tidak ada mata pelajaran yang cocok dengan pencarian Anda.
          </div>
        )}
      </div>

      {/* Form Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-slate-950/40 backdrop-blur-xs flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl w-full max-w-md shadow-2xl border border-slate-100 overflow-hidden animate-zoom-in">
            {/* Modal Header */}
            <div className="px-6 py-5 border-b border-slate-100 flex justify-between items-center bg-slate-50">
              <h2 className="font-display font-bold text-lg text-slate-900">
                {editingId ? 'Edit Mata Pelajaran' : 'Tambah Mapel Baru'}
              </h2>
              <button 
                onClick={() => setIsModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 hover:bg-slate-200/50 p-1.5 rounded-lg transition"
              >
                <X size={18} />
              </button>
            </div>

            {/* Modal Body / Form */}
            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              {/* Error Message */}
              {errorMsg && (
                <div className="bg-red-50 text-red-700 text-xs p-3.5 rounded-xl border border-red-100 flex items-center justify-between font-medium">
                  <span>{errorMsg}</span>
                  <button 
                    type="button" 
                    onClick={() => setErrorMsg(null)}
                    className="text-red-400 hover:text-red-600 transition p-1 rounded"
                  >
                    <X size={14} className="stroke-[2.5]" />
                  </button>
                </div>
              )}

              {/* Kode Mapel */}
              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1.5">Kode Mapel</label>
                <input
                  type="text"
                  required
                  placeholder="Contoh: MAT-04 atau IPA-05"
                  value={formData.code}
                  onChange={(e) => setFormData({...formData, code: e.target.value.toUpperCase()})}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 text-sm text-slate-800 focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500 transition font-mono uppercase"
                />
              </div>

              {/* Nama Mapel */}
              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1.5">Nama Mata Pelajaran</label>
                <input
                  type="text"
                  required
                  placeholder="Contoh: Ilmu Pengetahuan Alam (IPA)"
                  value={formData.name}
                  onChange={(e) => setFormData({...formData, name: e.target.value})}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 text-sm text-slate-800 focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500 transition"
                />
              </div>

              {/* Kurikulum */}
              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1.5">Kurikulum Acuan</label>
                <select
                  value={formData.kurikulum}
                  onChange={(e) => setFormData({...formData, kurikulum: e.target.value as CurriculumType})}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2.5 text-sm text-slate-800 focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500 transition font-medium"
                >
                  <option value="Kurikulum Merdeka">Kurikulum Merdeka</option>
                  <option value="K13">Kurikulum 2013 (K13)</option>
                </select>
              </div>

              {/* Modal Footer Buttons */}
              <div className="pt-4 border-t border-slate-100 flex justify-end space-x-2.5">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 rounded-xl text-xs font-semibold text-slate-600 transition"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-blue-600 hover:bg-blue-700 rounded-xl text-xs font-bold text-white shadow-md shadow-blue-600/10 transition"
                >
                  {editingId ? 'Simpan Perubahan' : 'Simpan Mapel'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
