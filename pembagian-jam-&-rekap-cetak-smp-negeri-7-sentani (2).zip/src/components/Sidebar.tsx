/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { 
  LayoutDashboard, 
  Users, 
  BookOpen, 
  School, 
  CalendarClock, 
  ClipboardList, 
  Printer, 
  RefreshCw,
  GraduationCap,
  Share2
} from 'lucide-react';
import { AcademicSettings, SemesterType } from '../types';

interface SidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  academicSettings: AcademicSettings;
  setAcademicSettings: (settings: AcademicSettings) => void;
  onResetToDefaults: () => void;
}

export default function Sidebar({
  activeTab,
  setActiveTab,
  academicSettings,
  setAcademicSettings,
  onResetToDefaults
}: SidebarProps) {
  const menuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'guru', label: 'Data Guru', icon: Users },
    { id: 'mapel', label: 'Mata Pelajaran', icon: BookOpen },
    { id: 'kelas', label: 'Daftar Kelas', icon: School },
    { id: 'pembagian', label: 'Pembagian Jam', icon: CalendarClock },
    { id: 'tugas', label: 'Tugas Tambahan', icon: ClipboardList },
    { id: 'rekap', label: 'Rekap & Cetak', icon: Printer },
    { id: 'sync', label: 'Cadangkan & Sync', icon: Share2 },
  ];

  const handleYearChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setAcademicSettings({
      ...academicSettings,
      academic_year: e.target.value
    });
  };

  const handleSemesterChange = (semester: SemesterType) => {
    setAcademicSettings({
      ...academicSettings,
      semester
    });
  };

  return (
    <div id="app-sidebar" className="w-80 bg-slate-900 text-slate-300 flex flex-col h-screen fixed left-0 top-0 no-print z-30 shadow-2xl">
      {/* School Brand Header */}
      <div className="p-6 border-b border-slate-800 flex items-center space-x-3.5">
        <div className="w-10 h-10 bg-blue-600 rounded flex items-center justify-center text-white font-bold text-xl shrink-0 shadow-lg shadow-blue-600/20">
          S7
        </div>
        <div>
          <h1 className="font-sans font-bold text-sm leading-tight uppercase tracking-wider text-white">SMP NEGERI 7</h1>
          <p className="text-xs opacity-60 uppercase tracking-wider">Sentani</p>
        </div>
      </div>

      {/* Academic Settings Control Panel */}
      <div className="px-6 py-4 bg-slate-950/40 border-b border-slate-800/60">
        <span className="text-[10px] font-bold text-slate-500 tracking-widest uppercase">Konfigurasi Aktif</span>
        
        <div className="mt-2 space-y-3">
          {/* Academic Year Selection */}
          <div>
            <label className="block text-xs font-medium text-slate-400 mb-1">Tahun Pelajaran (Manual)</label>
            <input 
              type="text"
              value={academicSettings.academic_year} 
              onChange={handleYearChange}
              placeholder="Contoh: 2025/2026"
              className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-white focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500 font-medium transition"
            />
          </div>

          {/* Semester Toggle */}
          <div>
            <label className="block text-xs font-medium text-slate-400 mb-1.5">Semester</label>
            <div className="grid grid-cols-2 gap-1 bg-slate-950 p-1 rounded-lg border border-slate-800">
              <button
                type="button"
                onClick={() => handleSemesterChange('Ganjil')}
                className={`py-1 text-center text-xs font-semibold rounded-md transition duration-150 ${
                  academicSettings.semester === 'Ganjil'
                    ? 'bg-blue-600 text-white shadow-md'
                    : 'text-slate-400 hover:text-white hover:bg-slate-800/40'
                }`}
              >
                Ganjil
              </button>
              <button
                type="button"
                onClick={() => handleSemesterChange('Genap')}
                className={`py-1 text-center text-xs font-semibold rounded-md transition duration-150 ${
                  academicSettings.semester === 'Genap'
                    ? 'bg-blue-600 text-white shadow-md'
                    : 'text-slate-400 hover:text-white hover:bg-slate-800/40'
                }`}
              >
                Genap
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Main Navigation Menu */}
      <nav className="flex-1 px-4 py-6 space-y-1 overflow-y-auto">
        <div className="p-2 text-[10px] uppercase font-semibold text-slate-500 tracking-widest mb-2">Menu Utama</div>
        {menuItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              id={`nav-link-${item.id}`}
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`w-full flex items-center space-x-3 px-3 py-2.5 rounded transition duration-200 group ${
                isActive
                  ? 'bg-blue-600/10 text-blue-400 border-l-4 border-blue-600 font-bold'
                  : 'text-slate-400 hover:bg-slate-800 hover:text-slate-200'
              }`}
            >
              <Icon 
                size={18} 
                className={`transition duration-200 shrink-0 ${
                  isActive ? 'text-blue-400 stroke-[2.5]' : 'text-slate-450 group-hover:text-slate-200'
                }`} 
              />
              <span className="text-sm tracking-wide">{item.label}</span>
              {item.id === 'rekap' && (
                <span className={`ml-auto text-[10px] uppercase font-bold tracking-wider px-1.5 py-0.5 rounded ${
                  isActive ? 'bg-blue-900 text-blue-400' : 'bg-blue-600/20 text-blue-400'
                }`}>
                  Print
                </span>
              )}
              {item.id === 'sync' && (
                <span className={`ml-auto text-[10px] uppercase font-bold tracking-wider px-1.5 py-0.5 rounded ${
                  isActive ? 'bg-indigo-900 text-indigo-400' : 'bg-indigo-600/20 text-indigo-400'
                }`}>
                  Link
                </span>
              )}
            </button>
          );
        })}
      </nav>

      {/* Footer Settings with Reset Button */}
      <div className="p-4 border-t border-slate-800/80 bg-slate-950/20">
        <button
          id="btn-reset-data"
          onClick={() => {
            if (window.confirm('Apakah Anda yakin ingin menyetel ulang data ke data bawaan awal (seed)? Semua perubahan Anda saat ini akan dihapus.')) {
              onResetToDefaults();
            }
          }}
          className="w-full flex items-center justify-center space-x-2 px-4 py-2.5 rounded-lg border border-slate-800 hover:border-red-500/30 hover:bg-red-950/20 text-slate-400 hover:text-red-400 text-xs font-semibold transition"
        >
          <RefreshCw size={14} className="stroke-[2]" />
          <span>Reset ke Data Bawaan</span>
        </button>
        <div className="mt-3 text-center">
          <span className="text-[10px] text-slate-600 font-medium">SMP Negeri 7 Sentani © 2026</span>
        </div>
      </div>
    </div>
  );
}
