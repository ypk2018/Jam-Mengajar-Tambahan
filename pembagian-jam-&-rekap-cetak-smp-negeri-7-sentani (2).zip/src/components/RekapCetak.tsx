/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  Printer, 
  FileText, 
  Layers, 
  Bookmark,
  CheckCircle,
  Eye,
  Settings,
  X,
  Upload
} from 'lucide-react';
import { Teacher, Subject, ClassRoom, TeachingAssignment, AdditionalTask, AcademicSettings } from '../types';

interface RekapCetakProps {
  teachers: Teacher[];
  subjects: Subject[];
  classes: ClassRoom[];
  assignments: TeachingAssignment[];
  additionalTasks: AdditionalTask[];
  academicSettings: AcademicSettings;
}

export default function RekapCetak({
  teachers,
  subjects,
  classes,
  assignments,
  additionalTasks,
  academicSettings
}: RekapCetakProps) {
  const [activeSubTab, setActiveSubTab] = useState<'beban' | 'rincian' | 'tambahan'>('beban');
  const [showPrintPreview, setShowPrintPreview] = useState(false);
  const [isLogoConfigOpen, setIsLogoConfigOpen] = useState(false);

  // Logo upload state
  const [logoPemda, setLogoPemda] = useState<string | null>(() => {
    return localStorage.getItem('logo_pemda') || null;
  });
  const [logoSekolah, setLogoSekolah] = useState<string | null>(() => {
    return localStorage.getItem('logo_sekolah') || null;
  });

  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>, type: 'pemda' | 'sekolah') => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Validate size (max 1.5MB to stay within safe LocalStorage limits)
    if (file.size > 1500000) {
      alert('Ukuran file terlalu besar! Silakan upload logo berukuran maksimal 1.5 MB.');
      return;
    }

    const reader = new FileReader();
    reader.onloadend = () => {
      const base64String = reader.result as string;
      try {
        if (type === 'pemda') {
          setLogoPemda(base64String);
          localStorage.setItem('logo_pemda', base64String);
        } else {
          setLogoSekolah(base64String);
          localStorage.setItem('logo_sekolah', base64String);
        }
      } catch (err) {
        alert('Gagal menyimpan gambar: kapasitas LocalStorage tidak mencukupi untuk file gambar sebesar ini. Silakan coba gambar dengan kompresi lebih tinggi.');
      }
    };
    reader.readAsDataURL(file);
  };

  const handleRemoveLogo = (type: 'pemda' | 'sekolah') => {
    if (type === 'pemda') {
      setLogoPemda(null);
      localStorage.removeItem('logo_pemda');
    } else {
      setLogoSekolah(null);
      localStorage.removeItem('logo_sekolah');
    }
  };

  // Filter current academic year assignments and tasks
  const currentAssignments = assignments.filter(
    a => a.academic_year === academicSettings.academic_year && a.semester === academicSettings.semester
  );

  const currentTasks = additionalTasks.filter(
    t => t.academic_year === academicSettings.academic_year
  );

  // Find Kepala Sekolah dynamically (from active academic year first, then overall additional tasks)
  const principalTask = currentTasks.find(task => 
    task.task_name.toLowerCase().includes('kepala sekolah')
  ) || additionalTasks.find(task => 
    task.task_name.toLowerCase().includes('kepala sekolah')
  );
  const principalTeacher = principalTask 
    ? teachers.find(t => t.id === principalTask.teacher_id) 
    : undefined;

  // Find Waka Kurikulum dynamically (e.g. task name includes 'kurikulum')
  const curriculumTask = currentTasks.find(task => 
    task.task_name.toLowerCase().includes('kurikulum')
  ) || additionalTasks.find(task => 
    task.task_name.toLowerCase().includes('kurikulum')
  );
  const curriculumTeacher = curriculumTask 
    ? teachers.find(t => t.id === curriculumTask.teacher_id) 
    : undefined;

  // ================= TAB 1: BEBAN GURU CALCULATIONS =================
  const teacherRecaps = teachers.map(teacher => {
    // Current assignments for this teacher
    const teacherAssigns = currentAssignments.filter(a => a.teacher_id === teacher.id);
    
    // Unique subjects taught
    const uniqueSubjectsCount = new Set(teacherAssigns.map(a => a.subject_id)).size;
    
    // Unique classes taught
    const uniqueClassesCount = new Set(teacherAssigns.map(a => a.class_id)).size;

    // Total Teaching JP
    const teachingJP = teacherAssigns.reduce((sum, a) => sum + a.hours_per_week, 0);

    // Additional tasks
    const teacherTasks = currentTasks.filter(t => t.teacher_id === teacher.id);
    const tasksJP = teacherTasks.reduce((sum, t) => sum + t.hours_equivalent, 0);
    const taskNames = teacherTasks.map(t => t.task_name).join(', ') || '-';

    // Total JP combined
    const grandTotalJP = teachingJP + tasksJP;

    return {
      ...teacher,
      subjectsCount: uniqueSubjectsCount,
      classesCount: uniqueClassesCount,
      teachingJP,
      tasksJP,
      taskNames,
      grandTotalJP
    };
  });

  // Level statistics for Tab 1 (Beban per Level)
  const getJPByLevelAndTeacher = (teacherId: string, level: 'VII' | 'VIII' | 'IX') => {
    return currentAssignments
      .filter(a => a.teacher_id === teacherId)
      .filter(a => {
        const cls = classes.find(c => c.id === a.class_id);
        return cls?.tingkat === level;
      })
      .reduce((sum, a) => sum + a.hours_per_week, 0);
  };

  // General counts
  const totalGuruSertifikasi = teacherRecaps.filter(t => t.grandTotalJP >= 24).length;
  const totalGuruKurangJam = teacherRecaps.filter(t => t.grandTotalJP < 18).length;

  // ================= TAB 2: RINCIAN JAM CALCULATIONS =================
  const levels: ('VII' | 'VIII' | 'IX')[] = ['VII', 'VIII', 'IX'];

  const getAssignmentsByLevel = (level: 'VII' | 'VIII' | 'IX') => {
    return currentAssignments
      .filter(a => {
        const cls = classes.find(c => c.id === a.class_id);
        return cls?.tingkat === level;
      })
      .map(a => {
        const teacher = teachers.find(t => t.id === a.teacher_id);
        const subject = subjects.find(s => s.id === a.subject_id);
        const cls = classes.find(c => c.id === a.class_id);
        return {
          ...a,
          teacherName: teacher?.name || 'Unknown',
          subjectName: subject?.name || 'Unknown',
          subjectCode: subject?.code || '-',
          className: cls?.name || 'Unknown'
        };
      })
      .sort((a, b) => a.className.localeCompare(b.className));
  };

  const assignmentByLevels = {
    'VII': getAssignmentsByLevel('VII'),
    'VIII': getAssignmentsByLevel('VIII'),
    'IX': getAssignmentsByLevel('IX')
  };

  const levelSubtotals = {
    'VII': assignmentByLevels['VII'].reduce((sum, a) => sum + a.hours_per_week, 0),
    'VIII': assignmentByLevels['VIII'].reduce((sum, a) => sum + a.hours_per_week, 0),
    'IX': assignmentByLevels['IX'].reduce((sum, a) => sum + a.hours_per_week, 0)
  };

  const grandTotalAllJP = levelSubtotals['VII'] + levelSubtotals['VIII'] + levelSubtotals['IX'];

  // Current Date formatting (Jayapura/Sentani time, June 2026)
  const getFormattedDateIndo = () => {
    const months = [
      'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
      'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'
    ];
    const today = new Date();
    const day = today.getDate();
    const month = months[today.getMonth()];
    const year = today.getFullYear();
    return `${day} ${month} ${year}`;
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-6">
      {/* Tab Controller (Screen View Only) */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 no-print animate-fade-in">
        <div>
          <h1 className="font-display font-bold text-3xl text-slate-950 tracking-tight">Rekap & Cetak Laporan</h1>
          <p className="text-slate-500 text-sm mt-1">
            Ekspor rekapitulasi beban mengajar guru, pembagian jam, dan tugas tambahan ke dokumen cetak / PDF.
          </p>
        </div>

        <div className="flex items-center space-x-3 shrink-0">
          <button
            onClick={() => setShowPrintPreview(!showPrintPreview)}
            className={`px-4 py-2.5 rounded-xl border font-semibold text-xs transition duration-200 flex items-center space-x-2 ${
              showPrintPreview 
                ? 'bg-blue-600 border-blue-600 text-white' 
                : 'bg-white hover:bg-slate-50 border-slate-200 text-slate-700 shadow-xs'
            }`}
          >
            <Eye size={15} />
            <span>{showPrintPreview ? 'Tutup Preview Cetak' : 'Preview Cetak'}</span>
          </button>
          
          <button
            onClick={handlePrint}
            className="bg-blue-600 hover:bg-blue-700 text-white font-semibold px-5 py-2.5 rounded-xl shadow-lg shadow-blue-500/15 flex items-center justify-center space-x-2 transition duration-200 text-xs"
          >
            <Printer size={15} className="stroke-[2.5]" />
            <span>Cetak PDF Laporan</span>
          </button>
        </div>
      </div>

      {/* Primary Sub-Tabs for Screens (No-Print) */}
      <div className="bg-white p-2 rounded-xl shadow-xs border border-slate-200 flex flex-wrap md:flex-nowrap gap-1 no-print">
        <button
          onClick={() => { setActiveSubTab('beban'); setShowPrintPreview(false); }}
          className={`w-full md:w-auto px-5 py-3 rounded-lg text-xs font-bold transition flex items-center justify-center space-x-2 ${
            activeSubTab === 'beban' && !showPrintPreview
              ? 'bg-blue-600 text-white shadow-xs'
              : 'text-slate-500 hover:text-slate-900 hover:bg-slate-50'
          }`}
        >
          <Layers size={14} />
          <span>Rekap Beban Kerja Guru</span>
        </button>

        <button
          onClick={() => { setActiveSubTab('rincian'); setShowPrintPreview(false); }}
          className={`w-full md:w-auto px-5 py-3 rounded-lg text-xs font-bold transition flex items-center justify-center space-x-2 ${
            activeSubTab === 'rincian' && !showPrintPreview
              ? 'bg-blue-600 text-white shadow-xs'
              : 'text-slate-500 hover:text-slate-900 hover:bg-slate-50'
          }`}
        >
          <FileText size={14} />
          <span>Rincian Pembagian Jam Rombel</span>
        </button>

        <button
          onClick={() => { setActiveSubTab('tambahan'); setShowPrintPreview(false); }}
          className={`w-full md:w-auto px-5 py-3 rounded-lg text-xs font-bold transition flex items-center justify-center space-x-2 ${
            activeSubTab === 'tambahan' && !showPrintPreview
              ? 'bg-blue-600 text-white shadow-xs'
              : 'text-slate-500 hover:text-slate-900 hover:bg-slate-50'
          }`}
        >
          <Bookmark size={14} />
          <span>Daftar Tugas Tambahan</span>
        </button>
      </div>

      {/* Settings / Configuration banner for Kop & Logo */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs no-print overflow-hidden transition-all duration-300">
        <button
          type="button"
          onClick={() => setIsLogoConfigOpen(!isLogoConfigOpen)}
          className="w-full px-5 py-4 flex items-center justify-between text-left hover:bg-slate-50 transition"
        >
          <div className="flex items-center space-x-3 text-slate-800">
            <Settings size={18} className="text-blue-600 stroke-[2]" />
            <div>
              <span className="text-xs font-bold uppercase tracking-wider block">Pengaturan Logo & KOP Laporan</span>
              <span className="text-[11px] text-slate-500 font-medium">Klik untuk upload / ubah Logo PEMDA, Logo Sekolah, dan format Kop Surat</span>
            </div>
          </div>
          <span className={`text-xs font-bold px-3 py-1.5 rounded-lg transition ${isLogoConfigOpen ? 'bg-slate-200 text-slate-700' : 'bg-blue-50 text-blue-650'}`}>
            {isLogoConfigOpen ? 'Tutup Pengaturan' : 'Buka Pengaturan'}
          </span>
        </button>

        {isLogoConfigOpen && (
          <div className="border-t border-slate-100 p-6 bg-slate-50/50 grid grid-cols-1 md:grid-cols-2 gap-6 animate-fade-in">
            {/* Logo Pemda */}
            <div className="bg-white p-5 rounded-xl border border-slate-200 space-y-4">
              <div className="flex items-center space-x-2">
                <span className="w-1.5 h-3.5 bg-blue-600 rounded-full" />
                <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider">Logo Pemerintah Daerah (Kiri Kop)</h4>
              </div>
              <div className="flex items-center space-x-5">
                <div className="w-16 h-16 bg-slate-50 border-2 border-dashed border-slate-200 rounded-xl flex items-center justify-center overflow-hidden shrink-0 shadow-inner">
                  {logoPemda ? (
                    <img src={logoPemda} alt="Logo Pemda" className="w-full h-full object-contain p-1" referrerPolicy="no-referrer" />
                  ) : (
                    <div className="text-[9px] font-bold text-slate-400 text-center leading-tight uppercase p-1">
                      No Logo<br/>Pemda
                    </div>
                  )}
                </div>
                <div className="flex-1 space-y-2">
                  <div className="flex flex-wrap gap-2">
                    <label className="cursor-pointer bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold px-3 py-1.5 rounded-lg transition shadow-xs flex items-center space-x-1">
                      <Upload size={12} />
                      <span>Upload Gambar</span>
                      <input
                        type="file"
                        accept="image/*"
                        onChange={(e) => handleLogoUpload(e, 'pemda')}
                        className="hidden"
                      />
                    </label>
                    {logoPemda && (
                      <button
                        type="button"
                        onClick={() => handleRemoveLogo('pemda')}
                        className="bg-red-50 hover:bg-red-100 text-red-600 text-xs font-bold px-3 py-1.5 rounded-lg transition"
                      >
                        Hapus
                      </button>
                    )}
                  </div>
                  <p className="text-[10px] text-slate-400">Rekomendasi file JPG/PNG transparan dengan aspek rasio 1:1.</p>
                </div>
              </div>
            </div>

            {/* Logo Sekolah */}
            <div className="bg-white p-5 rounded-xl border border-slate-200 space-y-4">
              <div className="flex items-center space-x-2">
                <span className="w-1.5 h-3.5 bg-blue-600 rounded-full" />
                <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider">Logo Instansi Sekolah (Kanan Kop)</h4>
              </div>
              <div className="flex items-center space-x-5">
                <div className="w-16 h-16 bg-slate-50 border-2 border-dashed border-slate-200 rounded-xl flex items-center justify-center overflow-hidden shrink-0 shadow-inner">
                  {logoSekolah ? (
                    <img src={logoSekolah} alt="Logo Sekolah" className="w-full h-full object-contain p-1" referrerPolicy="no-referrer" />
                  ) : (
                    <div className="text-[9px] font-bold text-slate-400 text-center leading-tight uppercase p-1">
                      No Logo<br/>Sekolah
                    </div>
                  )}
                </div>
                <div className="flex-1 space-y-2">
                  <div className="flex flex-wrap gap-2">
                    <label className="cursor-pointer bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold px-3 py-1.5 rounded-lg transition shadow-xs flex items-center space-x-1">
                      <Upload size={12} />
                      <span>Upload Gambar</span>
                      <input
                        type="file"
                        accept="image/*"
                        onChange={(e) => handleLogoUpload(e, 'sekolah')}
                        className="hidden"
                      />
                    </label>
                    {logoSekolah && (
                      <button
                        type="button"
                        onClick={() => handleRemoveLogo('sekolah')}
                        className="bg-red-50 hover:bg-red-100 text-red-600 text-xs font-bold px-3 py-1.5 rounded-lg transition"
                      >
                        Hapus
                      </button>
                    )}
                  </div>
                  <p className="text-[10px] text-slate-400">Rekomendasi file JPG/PNG transparan dengan aspek rasio 1:1.</p>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* ========================================================= */}
      {/* SCREEN VIEW MODE (Standard Interactive Screen Dashboards) */}
      {/* ========================================================= */}
      {!showPrintPreview && (
        <div className="no-print">
          {/* TAB 1: BEBAN GURU INTERACTIVE VIEW */}
          {activeSubTab === 'beban' && (
            <div className="space-y-6">
              {/* Quick Summary Widgets */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="bg-white p-5 rounded-xl border border-slate-200 flex items-center space-x-4 shadow-xs">
                  <div className="bg-blue-50 text-blue-600 p-3 rounded-lg">
                    <CheckCircle size={20} />
                  </div>
                  <div>
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Memenuhi Syarat Sertifikasi</span>
                    <h4 className="font-display font-bold text-xl text-slate-900 mt-1">{totalGuruSertifikasi} dari {teachers.length} Guru</h4>
                    <p className="text-[10px] text-slate-500 mt-0.5">Memiliki beban total &gt;= 24 JP</p>
                  </div>
                </div>

                <div className="bg-white p-5 rounded-xl border border-slate-200 flex items-center space-x-4 shadow-xs">
                  <div className="bg-amber-50 text-amber-600 p-3 rounded-lg">
                    <Printer size={20} />
                  </div>
                  <div>
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Kekurangan Jam</span>
                    <h4 className="font-display font-bold text-xl text-slate-900 mt-1">{totalGuruKurangJam} Guru</h4>
                    <p className="text-[10px] text-slate-500 mt-0.5">Memiliki beban total &lt; 18 JP</p>
                  </div>
                </div>

                <div className="bg-white p-5 rounded-xl border border-slate-200 flex items-center space-x-4 shadow-xs">
                  <div className="bg-indigo-50 text-indigo-600 p-3 rounded-lg">
                    <FileText size={20} />
                  </div>
                  <div>
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Total Jam Terdistribusi</span>
                    <h4 className="font-display font-bold text-xl text-slate-900 mt-1">{grandTotalAllJP} JP</h4>
                    <p className="text-[10px] text-slate-500 mt-0.5">Seluruh Rombongan Belajar</p>
                  </div>
                </div>
              </div>

              {/* Comprehensive Teacher Workload Table */}
              <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
                <div className="p-5 border-b border-slate-200 flex items-center justify-between bg-slate-50">
                  <h3 className="font-display font-bold text-sm text-slate-950">Rekapitulasi Total Beban Mengajar Guru</h3>
                  <span className="text-xs text-slate-500 font-bold font-mono">T.A. {academicSettings.academic_year}</span>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs md:text-sm">
                    <thead>
                      <tr className="bg-slate-50 border-b border-slate-200 text-slate-500 font-bold uppercase tracking-widest text-[10px]">
                        <th className="py-3.5 px-5">Nama Guru</th>
                        <th className="py-3.5 px-5">NIP</th>
                        <th className="py-3.5 px-5">Gol</th>
                        <th className="py-3.5 px-5">Status</th>
                        <th className="py-3.5 px-5 text-center">Tingkat VII</th>
                        <th className="py-3.5 px-5 text-center">Tingkat VIII</th>
                        <th className="py-3.5 px-5 text-center">Tingkat IX</th>
                        <th className="py-3.5 px-5 text-center">Mengajar (JP)</th>
                        <th className="py-3.5 px-5 text-center">Tugas Tambahan (JP)</th>
                        <th className="py-3.5 px-5 text-center font-bold text-slate-900">Total JP</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 text-slate-700">
                      {teacherRecaps.map(t => (
                        <tr key={t.id} className="hover:bg-slate-50/30 transition">
                          <td className="py-3.5 px-5 font-semibold text-slate-900">{t.name}</td>
                          <td className="py-3.5 px-5 font-mono text-slate-500">{t.nip || '-'}</td>
                          <td className="py-3.5 px-5 font-mono text-slate-500">{t.golongan}</td>
                          <td className="py-3.5 px-5">
                            <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                              t.status === 'PNS' ? 'bg-blue-50 text-blue-700 border border-blue-100' :
                              t.status === 'PPPK' ? 'bg-indigo-50 text-indigo-700 border border-indigo-100' :
                              'bg-slate-100 text-slate-600 border border-slate-200'
                            }`}>{t.status}</span>
                          </td>
                          <td className="py-3.5 px-5 text-center font-mono">{getJPByLevelAndTeacher(t.id, 'VII') || '-'}</td>
                          <td className="py-3.5 px-5 text-center font-mono">{getJPByLevelAndTeacher(t.id, 'VIII') || '-'}</td>
                          <td className="py-3.5 px-5 text-center font-mono">{getJPByLevelAndTeacher(t.id, 'IX') || '-'}</td>
                          <td className="py-3.5 px-5 text-center font-mono font-semibold text-slate-950">{t.teachingJP} JP</td>
                          <td className="py-3.5 px-5 text-center font-mono text-slate-500">{t.tasksJP} JP</td>
                          <td className={`py-3.5 px-5 text-center font-mono font-bold text-sm ${
                            t.grandTotalJP >= 24 ? 'text-blue-600' :
                            t.grandTotalJP < 18 ? 'text-amber-600' : 'text-slate-900'
                          }`}>{t.grandTotalJP} JP</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: DETAILED ASSIGNMENTS BY ROMBEL */}
          {activeSubTab === 'rincian' && (
            <div className="space-y-6">
              {levels.map(lvl => (
                <div key={lvl} className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
                  <div className="p-5 border-b border-slate-200 flex items-center justify-between bg-slate-50">
                    <h3 className="font-display font-bold text-sm text-slate-950">
                      Rincian Pembagian Jam Pelajaran - Tingkat {lvl}
                    </h3>
                    <span className="bg-blue-50 text-blue-700 font-bold px-3 py-1 rounded border border-blue-100 text-xs font-mono">
                      Subtotal: {levelSubtotals[lvl]} JP
                    </span>
                  </div>

                  <div className="overflow-x-auto">
                    <table className="w-full text-left text-xs md:text-sm">
                      <thead>
                        <tr className="bg-slate-50 border-b border-slate-200 text-slate-500 font-bold uppercase tracking-widest text-[10px]">
                          <th className="py-3 px-6">Kelas Rombel</th>
                          <th className="py-3 px-6">Kode & Mata Pelajaran</th>
                          <th className="py-3 px-6">Guru Pengampu</th>
                          <th className="py-3 px-6 text-center">Alokasi Beban (JP)</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100 text-slate-700">
                        {assignmentByLevels[lvl].length > 0 ? (
                          assignmentByLevels[lvl].map(a => (
                            <tr key={a.id} className="hover:bg-slate-50/20 transition">
                              <td className="py-3.5 px-6 font-bold text-slate-800">{a.className}</td>
                              <td className="py-3.5 px-6">
                                <span className="font-mono text-[10px] font-bold bg-slate-100 text-slate-500 px-1.5 py-0.5 rounded border mr-2">{a.subjectCode}</span>
                                <span className="font-semibold text-slate-900">{a.subjectName}</span>
                              </td>
                              <td className="py-3.5 px-6 font-medium text-slate-600">{a.teacherName}</td>
                              <td className="py-3.5 px-6 text-center font-mono font-bold text-slate-950">{a.hours_per_week} JP</td>
                            </tr>
                          ))
                        ) : (
                          <tr>
                            <td colSpan={4} className="py-8 text-center text-slate-400 font-medium">
                              Belum ada jam pelajaran terdistribusi untuk Tingkat {lvl} di semester ini.
                            </td>
                          </tr>
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>
              ))}

              {/* Grand Total Footer */}
              <div className="bg-blue-600 text-white p-6 rounded-xl shadow-md flex items-center justify-between">
                <div>
                  <h4 className="font-display font-bold text-white text-xs uppercase tracking-wider">Grand Total Jam Pelajaran Terbagi</h4>
                  <p className="text-xs text-blue-100 mt-1">Menggabungkan seluruh tingkatan rombel VII, VIII, IX</p>
                </div>
                <div className="text-right">
                  <span className="font-display font-extrabold text-3xl text-white font-mono">{grandTotalAllJP} JP</span>
                  <span className="text-blue-100 text-xs block font-semibold">Per Minggu</span>
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: ADDITIONAL TASKS */}
          {activeSubTab === 'tambahan' && (
            <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
              <div className="p-5 border-b border-slate-200 bg-slate-50">
                <h3 className="font-display font-bold text-sm text-slate-950">Daftar Lengkap Pemegang Tugas Tambahan Fungsional</h3>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs md:text-sm">
                  <thead>
                    <tr className="bg-slate-50 border-b border-slate-200 text-slate-500 font-bold uppercase tracking-widest text-[10px]">
                      <th className="py-3.5 px-6">Tugas Tambahan (Jabatan)</th>
                      <th className="py-3.5 px-6">Guru Penanggung Jawab</th>
                      <th className="py-3.5 px-6">Status Kepegawaian</th>
                      <th className="py-3.5 px-6 text-center">Beban Ekuivalen (JP)</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 text-slate-700">
                    {currentTasks.length > 0 ? (
                      currentTasks.map(task => {
                        const t = teachers.find(teacher => teacher.id === task.teacher_id);
                        return (
                          <tr key={task.id} className="hover:bg-slate-50/30 transition">
                            <td className="py-3.5 px-6 font-bold text-slate-950">{task.task_name}</td>
                            <td className="py-3.5 px-6 font-semibold text-slate-700">{t ? t.name : 'Unknown'}</td>
                            <td className="py-3.5 px-6">
                              {t ? (
                                <span className="text-slate-500 font-semibold text-xs font-mono">
                                  {t.nip ? `NIP: ${t.nip}` : 'PNS'} ({t.status})
                                </span>
                              ) : '-'}
                            </td>
                            <td className="py-3.5 px-6 text-center font-mono font-bold text-slate-950 text-base">{task.hours_equivalent} JP</td>
                          </tr>
                        );
                      })
                    ) : (
                      <tr>
                        <td colSpan={4} className="py-12 text-center text-slate-400 font-medium">
                          Tidak ada data tugas tambahan guru pada semester aktif ini.
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      )}

      {/* ========================================================= */}
      {/* PRINT-READY PREVIEW CONTAINER (Always rendered in @media print) */}
      {/* ========================================================= */}
      {(showPrintPreview || true) && (
        <div id="print-layout-container" className={`${showPrintPreview ? 'block bg-white p-12 border border-slate-200 rounded-2xl shadow-lg max-w-5xl mx-auto' : 'hidden'} print-only print-container`}>
          {/* 1. KOP SURAT (Official School Letterhead) */}
          <div className="text-center border-b-[4px] border-double border-slate-900 pb-3 mb-6 relative px-20 min-h-[84px] flex flex-col justify-center">
            {/* Logo Pemda (Kiri Kop) */}
            <div className="absolute left-0 top-1/2 -translate-y-1/2 w-16 h-16 flex items-center justify-center">
              {logoPemda ? (
                <img src={logoPemda} alt="Logo Pemda" className="w-16 h-16 object-contain" referrerPolicy="no-referrer" />
              ) : (
                <div className="w-14 h-14 border-2 border-slate-350 rounded-full flex items-center justify-center font-bold text-[8px] text-slate-400 p-1 text-center leading-tight uppercase bg-slate-50">
                  Logo<br/>Pemda
                </div>
              )}
            </div>

            {/* Kop Surat Text Info */}
            <div className="text-center">
              <h4 className="font-bold text-xs tracking-widest uppercase text-slate-900 font-sans">Pemerintah Kabupaten Jayapura</h4>
              <h3 className="font-bold text-sm tracking-wider uppercase text-slate-900 font-sans mt-0.5">Dinas Pendidikan</h3>
              <h2 className="font-display font-extrabold text-lg tracking-tight uppercase text-slate-950 mt-1">SMP Negeri 7 Sentani</h2>
              <p className="text-[10px] text-slate-600 font-medium italic mt-0.5 font-sans leading-normal">
                Alamat: Jl. Sereh, Distrik Sentani, Kabupaten Jayapura, Papua • Telp/Fax: (0967) 531234
              </p>
            </div>

            {/* Logo Sekolah (Kanan Kop) */}
            <div className="absolute right-0 top-1/2 -translate-y-1/2 w-16 h-16 flex items-center justify-center">
              {logoSekolah ? (
                <img src={logoSekolah} alt="Logo Sekolah" className="w-16 h-16 object-contain" referrerPolicy="no-referrer" />
              ) : (
                <div className="w-14 h-14 border-2 border-slate-350 rounded-full flex items-center justify-center font-bold text-[8px] text-slate-400 p-1 text-center leading-tight uppercase bg-slate-50">
                  Logo<br/>Sekolah
                </div>
              )}
            </div>
          </div>

          {/* Document Title Header */}
          <div className="text-center mb-8">
            <h3 className="font-display font-bold text-base uppercase text-slate-950 tracking-tight">
              REKAPITULASI PEMBAGIAN JAM MENGAJAR DAN TUGAS TAMBAHAN GURU
            </h3>
            <p className="text-xs font-semibold text-slate-700 uppercase tracking-widest mt-1">
              TAHUN PELAJARAN {academicSettings.academic_year} • SEMESTER {academicSettings.semester}
            </p>
          </div>

          {/* Render All Three Recaps Sequentially on Print */}
          <div className="space-y-10">
            {/* PRINT SECT 1: BEBAN GURU REKAPITULASI */}
            <div>
              <div className="border-b border-slate-900 pb-1.5 mb-3">
                <h4 className="font-bold text-xs uppercase tracking-wider text-slate-900">
                  I. Rekapitulasi Alokasi Beban Kerja Guru (JP / Minggu)
                </h4>
              </div>
              <table className="w-full text-xs text-slate-900 border-collapse border border-slate-900">
                <thead>
                  <tr className="bg-slate-100">
                    <th className="border border-slate-900 py-1.5 px-2 font-bold text-left">Nama Guru</th>
                    <th className="border border-slate-900 py-1.5 px-2 font-bold text-left">NIP</th>
                    <th className="border border-slate-900 py-1.5 px-2 font-bold text-center">Status</th>
                    <th className="border border-slate-900 py-1.5 px-2 font-bold text-center">Kelas VII</th>
                    <th className="border border-slate-900 py-1.5 px-2 font-bold text-center">Kelas VIII</th>
                    <th className="border border-slate-900 py-1.5 px-2 font-bold text-center">Kelas IX</th>
                    <th className="border border-slate-900 py-1.5 px-2 font-bold text-center">KBM (JP)</th>
                    <th className="border border-slate-900 py-1.5 px-2 font-bold text-center">Tugas Tambahan</th>
                    <th className="border border-slate-900 py-1.5 px-2 font-bold text-center">Total JP</th>
                  </tr>
                </thead>
                <tbody>
                  {teacherRecaps.map(t => (
                    <tr key={t.id}>
                      <td className="border border-slate-900 py-1.5 px-2 font-semibold">{t.name}</td>
                      <td className="border border-slate-900 py-1.5 px-2 font-mono text-[10px]">{t.nip || '-'}</td>
                      <td className="border border-slate-900 py-1.5 px-2 text-center font-medium text-[10px]">{t.status}</td>
                      <td className="border border-slate-900 py-1.5 px-2 text-center font-mono">{getJPByLevelAndTeacher(t.id, 'VII') || '-'}</td>
                      <td className="border border-slate-900 py-1.5 px-2 text-center font-mono">{getJPByLevelAndTeacher(t.id, 'VIII') || '-'}</td>
                      <td className="border border-slate-900 py-1.5 px-2 text-center font-mono">{getJPByLevelAndTeacher(t.id, 'IX') || '-'}</td>
                      <td className="border border-slate-900 py-1.5 px-2 text-center font-mono">{t.teachingJP} JP</td>
                      <td className="border border-slate-900 py-1.5 px-2 text-left font-medium text-[10px] truncate max-w-[150px]">{t.taskNames}</td>
                      <td className="border border-slate-900 py-1.5 px-2 text-center font-mono font-bold">{t.grandTotalJP} JP</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* PRINT SECT 2: RINCIAN ALOKASI KELAS */}
            <div className="page-break-before">
              <div className="border-b border-slate-900 pb-1.5 mb-3 mt-6">
                <h4 className="font-bold text-xs uppercase tracking-wider text-slate-900">
                  II. Rincian Penugasan Mengajar Per Kelas Rombongan Belajar
                </h4>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {levels.map(lvl => (
                  <div key={lvl} className="border border-slate-900 p-3 rounded bg-white">
                    <h5 className="font-bold text-xs border-b border-slate-900 pb-1 mb-2 uppercase tracking-wide text-slate-900">Tingkat {lvl} (Total: {levelSubtotals[lvl]} JP)</h5>
                    <table className="w-full text-[10px] text-slate-900 border-collapse">
                      <thead>
                        <tr className="border-b border-slate-900 text-left">
                          <th className="pb-1 font-bold">Kelas</th>
                          <th className="pb-1 font-bold">Mata Pelajaran</th>
                          <th className="pb-1 font-bold text-right">JP</th>
                        </tr>
                      </thead>
                      <tbody>
                        {assignmentByLevels[lvl].map(a => (
                          <tr key={a.id} className="border-b border-slate-100">
                            <td className="py-1 font-bold text-slate-900">{a.className.replace('Kelas ', '')}</td>
                            <td className="py-1 text-slate-700 truncate max-w-[120px]">{a.subjectName}</td>
                            <td className="py-1 text-right font-mono font-bold text-slate-900">{a.hours_per_week}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                ))}
              </div>
            </div>

            {/* PRINT SECT 3: JABATAN TAMBAHAN */}
            <div>
              <div className="border-b border-slate-900 pb-1.5 mb-3 mt-6">
                <h4 className="font-bold text-xs uppercase tracking-wider text-slate-900">
                  III. Penugasan Tugas Tambahan Fungsional Guru
                </h4>
              </div>
              <table className="w-full text-xs text-slate-900 border-collapse border border-slate-900">
                <thead>
                  <tr className="bg-slate-100">
                    <th className="border border-slate-900 py-1.5 px-2 font-bold text-left">Jabatan Tugas Tambahan</th>
                    <th className="border border-slate-900 py-1.5 px-2 font-bold text-left">Nama Guru Penanggung Jawab</th>
                    <th className="border border-slate-900 py-1.5 px-2 font-bold text-left">Status NIP / Golongan</th>
                    <th className="border border-slate-900 py-1.5 px-2 font-bold text-center">Beban Kerja Ekuivalen</th>
                  </tr>
                </thead>
                <tbody>
                  {currentTasks.map(task => {
                    const t = teachers.find(teacher => teacher.id === task.teacher_id);
                    return (
                      <tr key={task.id}>
                        <td className="border border-slate-900 py-1.5 px-2 font-bold">{task.task_name}</td>
                        <td className="border border-slate-900 py-1.5 px-2 font-semibold">{t ? t.name : 'Unknown'}</td>
                        <td className="border border-slate-900 py-1.5 px-2 font-mono text-[10px]">
                          {t ? `${t.nip ? `NIP. ${t.nip}` : 'PNS'} (Gol. ${t.golongan})` : '-'}
                        </td>
                        <td className="border border-slate-900 py-1.5 px-2 text-center font-mono font-bold">{task.hours_equivalent} JP</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>

          {/* 3. SIGNATURE BLOCKS FOR KEPALA SEKOLAH (Principal) */}
          <div className="mt-12 flex justify-between items-start text-xs text-slate-900">
            {/* Left side spacer or other signature (e.g. Wakasek Kurikulum) */}
            <div>
              <p>Sentani, {getFormattedDateIndo()}</p>
              <p className="font-semibold uppercase mt-0.5">
                {curriculumTask?.task_name || 'Wakil Kepala Sekolah Bidang Kurikulum'}
              </p>
              <div className="h-20" /> {/* signature spacing */}
              <p className="font-bold underline">
                {curriculumTeacher?.name || 'Mariana Ondikeleuw, S.Pd'}
              </p>
              <p className="text-[10px] font-mono mt-0.5 text-slate-600">
                {curriculumTeacher 
                  ? (curriculumTeacher.nip ? `NIP. ${curriculumTeacher.nip}` : 'NIP. -') 
                  : 'NIP. 197509182005012011'}
              </p>
            </div>

            {/* Right side primary signature - Kepala Sekolah */}
            <div className="text-right">
              <p>Mengetahui,</p>
              <p className="font-semibold uppercase mt-0.5">
                {principalTask?.task_name || 'Kepala Sekolah SMP Negeri 7 Sentani'}
              </p>
              <div className="h-20" /> {/* signature spacing */}
              <p className="font-bold underline text-slate-950">
                {principalTeacher?.name || 'Drs. Yohanis Wally, M.Pd'}
              </p>
              <p className="text-[10px] font-mono mt-0.5 text-slate-600">
                {principalTeacher 
                  ? (principalTeacher.nip ? `NIP. ${principalTeacher.nip}` : 'NIP. -') 
                  : 'NIP. 196805121994031008'}
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
