/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  Share2, 
  Download, 
  Upload, 
  Copy, 
  Check, 
  Database, 
  AlertTriangle, 
  Info, 
  FileJson, 
  Smartphone, 
  Laptop, 
  CheckCircle,
  HelpCircle,
  RefreshCw
} from 'lucide-react';
import { Teacher, Subject, ClassRoom, TeachingAssignment, AdditionalTask, AcademicSettings } from '../types';

interface BackupSyncManagerProps {
  teachers: Teacher[];
  subjects: Subject[];
  classes: ClassRoom[];
  assignments: TeachingAssignment[];
  additionalTasks: AdditionalTask[];
  academicSettings: AcademicSettings;
  onImportAll: (data: {
    settings?: AcademicSettings;
    teachers?: Teacher[];
    subjects?: Subject[];
    classes?: ClassRoom[];
    assignments?: TeachingAssignment[];
    tasks?: AdditionalTask[];
    logoPemda?: string | null;
    logoSekolah?: string | null;
  }) => void;
}

// UTF-8 base64 encoding helper
function encodeData(data: any): string {
  try {
    const jsonStr = JSON.stringify(data);
    const utf8Bytes = new TextEncoder().encode(jsonStr);
    let binString = "";
    for (let i = 0; i < utf8Bytes.length; i++) {
      binString += String.fromCharCode(utf8Bytes[i]);
    }
    return btoa(binString);
  } catch (e) {
    console.error(e);
    return "";
  }
}

// UTF-8 base64 decoding helper
function decodeData(encoded: string): any {
  try {
    const binString = atob(encoded);
    const len = binString.length;
    const bytes = new Uint8Array(len);
    for (let i = 0; i < len; i++) {
      bytes[i] = binString.charCodeAt(i);
    }
    const jsonStr = new TextDecoder().decode(bytes);
    return JSON.parse(jsonStr);
  } catch (e) {
    console.error(e);
    return null;
  }
}

// Payload key compression helper to make URL link significantly shorter
function compressPayload(payload: any): any {
  if (!payload) return null;
  const defaultYear = payload.settings?.academic_year || '';
  return {
    s: payload.settings ? {
      y: payload.settings.academic_year,
      m: payload.settings.semester
    } : undefined,
    t: payload.teachers?.map((x: any) => ({
      i: x.id,
      n: x.name,
      p: x.nip || undefined,
      g: x.golongan,
      s: x.status,
      b: x.bidang_studi
    })),
    u: payload.subjects?.map((x: any) => ({
      i: x.id,
      n: x.name,
      c: x.code,
      k: x.kelompok
    })),
    c: payload.classes?.map((x: any) => ({
      i: x.id,
      n: x.name,
      t: x.tingkat
    })),
    a: payload.assignments?.map((x: any) => {
      const row: any = {
        i: x.id,
        t: x.teacher_id,
        s: x.subject_id,
        c: x.class_id,
        h: x.hours_per_week
      };
      if (x.academic_year !== defaultYear) {
        row.y = x.academic_year;
      }
      return row;
    }),
    k: payload.tasks?.map((x: any) => {
      const row: any = {
        i: x.id,
        t: x.teacher_id,
        n: x.task_name,
        h: x.hours_equivalent
      };
      if (x.task_description) row.d = x.task_description;
      if (x.academic_year !== defaultYear) {
        row.y = x.academic_year;
      }
      return row;
    })
  };
}

export default function BackupSyncManager({
  teachers,
  subjects,
  classes,
  assignments,
  additionalTasks,
  academicSettings,
  onImportAll
}: BackupSyncManagerProps) {
  const [copied, setCopied] = useState(false);
  const [shareUrl, setShareUrl] = useState('');
  const [importedStatus, setImportedStatus] = useState<{ success: boolean; message: string } | null>(null);
  const [logoPemda, setLogoPemda] = useState<string | null>(null);
  const [logoSekolah, setLogoSekolah] = useState<string | null>(null);

  // Load logos from localStorage on mount
  useEffect(() => {
    setLogoPemda(localStorage.getItem('logo_pemda') || null);
    setLogoSekolah(localStorage.getItem('logo_sekolah') || null);
  }, []);

  // Construct current state payload
  const getCurrentPayload = (includeLogos: boolean) => {
    return {
      settings: academicSettings,
      teachers,
      subjects,
      classes,
      assignments,
      tasks: additionalTasks,
      logoPemda: includeLogos ? localStorage.getItem('logo_pemda') : null,
      logoSekolah: includeLogos ? localStorage.getItem('logo_sekolah') : null,
      version: '1.1',
      timestamp: Date.now()
    };
  };

  // Generate share link
  const handleGenerateShareLink = () => {
    // Generate data payload without logos first to prevent hitting URL length limits (approx 8-16KB safe)
    const payload = getCurrentPayload(false);
    const compressed = compressPayload(payload);
    const base64Data = encodeData(compressed);
    
    // Construct direct dev or pre preview URL with data parameter
    const baseUrl = window.location.origin + window.location.pathname;
    const fullLink = `${baseUrl}?data=${base64Data}`;
    setShareUrl(fullLink);

    // Copy to clipboard
    navigator.clipboard.writeText(fullLink)
      .then(() => {
        setCopied(true);
        setTimeout(() => setCopied(false), 3000);
      })
      .catch(err => {
        console.error('Failed to copy to clipboard', err);
      });
  };

  // Export JSON file
  const handleExportJson = () => {
    // Include logos in file export since files have no capacity limit
    const payload = getCurrentPayload(true);
    const dataStr = JSON.stringify(payload, null, 2);
    const blob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    
    const dateStr = new Date().toISOString().slice(0, 10);
    const fileName = `SMP7_Cadangan_Data_${academicSettings.academic_year.replace('/', '-')}_Semester-${academicSettings.semester}_${dateStr}.json`;
    
    const link = document.createElement('a');
    link.href = url;
    link.download = fileName;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  // Import JSON file
  const handleImportJson = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const content = event.target?.result as string;
        const parsed = JSON.parse(content);
        
        if (!parsed.teachers || !parsed.subjects) {
          setImportedStatus({
            success: false,
            message: 'Format file tidak sesuai. File cadangan harus memuat daftar Guru dan Mata Pelajaran yang valid.'
          });
          return;
        }

        // Apply changes
        onImportAll(parsed);
        
        // Reload logos state from localStorage after import updates it
        setTimeout(() => {
          setLogoPemda(localStorage.getItem('logo_pemda') || null);
          setLogoSekolah(localStorage.getItem('logo_sekolah') || null);
        }, 100);

        setImportedStatus({
          success: true,
          message: 'Seluruh data berhasil dipulihkan secara penuh! Semua komponen telah disesuaikan.'
        });
      } catch (err) {
        setImportedStatus({
          success: false,
          message: 'Gagal membaca file cadangan. Pastikan file berupa format JSON yang valid.'
        });
      }
    };
    reader.readAsText(file);
    e.target.value = ''; // Reset input element
  };

  return (
    <div className="space-y-8 animate-fade-in" id="backup-sync-view">
      {/* Top Welcome Title Banner */}
      <div className="bg-slate-900 text-white rounded-2xl p-6 md:p-8 shadow-xl relative overflow-hidden">
        {/* Abstract background graphics */}
        <div className="absolute right-0 top-0 w-80 h-80 bg-blue-600/15 rounded-full blur-3xl -mr-20 -mt-20 pointer-events-none" />
        <div className="absolute left-1/3 bottom-0 w-60 h-60 bg-indigo-600/10 rounded-full blur-2xl -ml-10 -mb-10 pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center space-x-2 bg-blue-500/20 text-blue-300 px-3 py-1 rounded-full text-xs font-semibold uppercase tracking-wider">
              <Database size={12} />
              <span>Sinkronisasi Perangkat</span>
            </div>
            <h1 className="text-2xl md:text-3xl font-display font-extrabold tracking-tight">Cadangkan & Pindahkan Data</h1>
            <p className="text-slate-300 text-sm md:text-base max-w-2xl leading-relaxed">
              Semua data Anda saat ini tersimpan otomatis di browser komputer/HP ini. Gunakan halaman ini untuk mencadangkan data secara mandiri, membagikan pekerjaan, atau berpindah ke komputer baru tanpa kehilangan data Anda sedikit pun.
            </p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left column: Method cards */}
        <div className="lg:col-span-2 space-y-8">
          {/* Method 1: URL Shareable Link */}
          <div className="bg-white rounded-2xl border border-slate-200 shadow-xs p-6 md:p-8 space-y-6">
            <div className="flex items-start space-x-4">
              <div className="p-3.5 bg-blue-50 text-blue-600 rounded-xl shrink-0">
                <Share2 size={24} className="stroke-[2]" />
              </div>
              <div className="space-y-1">
                <span className="text-[10px] font-bold text-blue-600 uppercase tracking-widest block">Metode Instan</span>
                <h3 className="text-lg font-sans font-bold text-slate-900">Salin Link Sinkronisasi Lintas Device</h3>
                <p className="text-slate-500 text-sm leading-relaxed">
                  Teknologi sinkronisasi tercanggih kami mengompresi seluruh data Anda (Data Guru, Mapel, Kelas, Jam Mengajar, & Tugas Tambahan) ke dalam satu link khusus. Cukup buka link tersebut di komputer/HP baru untuk memulihkan seluruh data secara instan!
                </p>
              </div>
            </div>

            <div className="bg-slate-50 p-5 rounded-xl border border-slate-200 space-y-4">
              <div className="flex flex-col sm:flex-row gap-3">
                <button
                  type="button"
                  onClick={handleGenerateShareLink}
                  className={`flex items-center justify-center space-x-2 px-5 py-3 rounded-lg text-sm font-bold transition duration-200 shrink-0 ${
                    copied 
                      ? 'bg-emerald-600 text-white hover:bg-emerald-700 shadow-md' 
                      : 'bg-blue-600 text-white hover:bg-blue-700 shadow-lg shadow-blue-600/15'
                  }`}
                >
                  {copied ? <Check size={16} /> : <Share2 size={16} />}
                  <span>{copied ? 'Link Berhasil Disalin!' : 'Salin Link Sinkronisasi'}</span>
                </button>

                <p className="text-xs text-slate-500 flex items-center leading-normal">
                  <Info size={16} className="text-blue-500 mr-2 shrink-0" />
                  Gunakan link ini untuk membuka data di browser lain, kirim ke WhatsApp, atau dibagikan ke Wakil Kurikulum lain.
                </p>
              </div>

              {shareUrl && (
                <div className="space-y-2 animate-fade-in">
                  <label className="block text-xs font-bold text-slate-600 uppercase tracking-wider">Hasil Link Tautan Data:</label>
                  <div className="flex items-center space-x-2 bg-white p-3 rounded-lg border border-slate-200 text-xs font-mono text-slate-600 overflow-x-auto whitespace-nowrap scrollbar-thin select-all shadow-inner">
                    {shareUrl}
                  </div>
                  <p className="text-[11px] text-amber-600 font-medium flex items-center">
                    <AlertTriangle size={14} className="mr-1 shrink-0" />
                    Catatan: Karena pembatasan panjang tautan browser, gambar Logo KOP tidak dimasukkan dalam link ini. Untuk memindahkan Logo KOP, silakan gunakan metode File Cadangan di bawah.
                  </p>
                </div>
              )}
            </div>
          </div>

          {/* Method 2: JSON Backup & Restore File */}
          <div className="bg-white rounded-2xl border border-slate-200 shadow-xs p-6 md:p-8 space-y-6">
            <div className="flex items-start space-x-4">
              <div className="p-3.5 bg-indigo-50 text-indigo-600 rounded-xl shrink-0">
                <FileJson size={24} className="stroke-[2]" />
              </div>
              <div className="space-y-1">
                <span className="text-[10px] font-bold text-indigo-600 uppercase tracking-widest block">Metode File Fisik</span>
                <h3 className="text-lg font-sans font-bold text-slate-900">Ekspor & Impor File Cadangan Lengkap (.json)</h3>
                <p className="text-slate-500 text-sm leading-relaxed">
                  Simpan cadangan data Anda sebagai file fisik di harddisk komputer, flashdisk, atau Google Drive. Metode ini mencakup **seluruh data termasuk file gambar Logo KOP Surat (PEMDA & Sekolah)** secara utuh.
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {/* Export Card */}
              <div className="border border-slate-200 rounded-xl p-5 hover:border-indigo-200 hover:bg-indigo-50/10 transition space-y-3 flex flex-col justify-between">
                <div className="space-y-1.5">
                  <h4 className="font-bold text-sm text-slate-800">Unduh File Cadangan</h4>
                  <p className="text-xs text-slate-500 leading-relaxed">Simpan semua data aktif + gambar Logo KOP ke file lokal Anda sekarang.</p>
                </div>
                <button
                  type="button"
                  onClick={handleExportJson}
                  className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-2.5 px-4 rounded-lg text-xs flex items-center justify-center space-x-1.5 transition"
                >
                  <Download size={14} />
                  <span>Ekspor File Cadangan</span>
                </button>
              </div>

              {/* Import Card */}
              <div className="border border-slate-200 rounded-xl p-5 hover:border-blue-200 hover:bg-blue-50/10 transition space-y-3 flex flex-col justify-between">
                <div className="space-y-1.5">
                  <h4 className="font-bold text-sm text-slate-800">Unggah File Cadangan</h4>
                  <p className="text-xs text-slate-500 leading-relaxed">Pulihkan seluruh data dari file .json cadangan yang telah diekspor sebelumnya.</p>
                </div>
                <div>
                  <label className="cursor-pointer w-full bg-slate-800 hover:bg-slate-900 text-white font-bold py-2.5 px-4 rounded-lg text-xs flex items-center justify-center space-x-1.5 transition">
                    <Upload size={14} />
                    <span>Impor File Cadangan</span>
                    <input
                      type="file"
                      accept=".json"
                      onChange={handleImportJson}
                      className="hidden"
                    />
                  </label>
                </div>
              </div>
            </div>

            {/* Imported/Error Messages */}
            {importedStatus && (
              <div className={`p-4 rounded-xl flex items-start space-x-3 text-sm animate-fade-in ${
                importedStatus.success ? 'bg-emerald-50 text-emerald-800 border border-emerald-200' : 'bg-rose-50 text-rose-800 border border-rose-200'
              }`}>
                {importedStatus.success ? (
                  <CheckCircle size={18} className="text-emerald-600 shrink-0 mt-0.5" />
                ) : (
                  <AlertTriangle size={18} className="text-rose-600 shrink-0 mt-0.5" />
                )}
                <div className="flex-1">
                  <p className="font-bold">{importedStatus.success ? 'Pemulihan Berhasil!' : 'Kesalahan Impor'}</p>
                  <p className="text-xs mt-0.5 leading-relaxed">{importedStatus.message}</p>
                </div>
                <button
                  type="button"
                  onClick={() => setImportedStatus(null)}
                  className="text-xs font-semibold underline shrink-0 hover:opacity-85"
                >
                  Tutup
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Right column: Current Data Stats & Instructions */}
        <div className="space-y-8">
          {/* Live Data Summary Card */}
          <div className="bg-white rounded-2xl border border-slate-200 shadow-xs p-6 space-y-4">
            <div className="flex items-center space-x-2">
              <Database size={16} className="text-slate-500" />
              <h4 className="font-display font-bold text-xs text-slate-700 uppercase tracking-wider">Statistik Database Perangkat</h4>
            </div>
            
            <div className="grid grid-cols-2 gap-3.5">
              <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200/80">
                <span className="text-[10px] text-slate-500 font-bold uppercase tracking-wider block">Total Guru</span>
                <span className="text-xl font-extrabold text-slate-800">{teachers.length} <span className="text-xs font-medium text-slate-400">orang</span></span>
              </div>
              <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200/80">
                <span className="text-[10px] text-slate-500 font-bold uppercase tracking-wider block">Mata Pelajaran</span>
                <span className="text-xl font-extrabold text-slate-800">{subjects.length} <span className="text-xs font-medium text-slate-400">studi</span></span>
              </div>
              <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200/80">
                <span className="text-[10px] text-slate-500 font-bold uppercase tracking-wider block">Daftar Kelas</span>
                <span className="text-xl font-extrabold text-slate-800">{classes.length} <span className="text-xs font-medium text-slate-400">ruang</span></span>
              </div>
              <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200/80">
                <span className="text-[10px] text-slate-500 font-bold uppercase tracking-wider block">Tugas Mengajar</span>
                <span className="text-xl font-extrabold text-slate-800">{assignments.length} <span className="text-xs font-medium text-slate-400">KBM</span></span>
              </div>
            </div>

            <div className="border-t border-slate-100 pt-4 space-y-2 text-xs text-slate-600">
              <div className="flex justify-between">
                <span className="font-medium">Tugas Tambahan:</span>
                <span className="font-bold text-slate-800">{additionalTasks.length} tugas</span>
              </div>
              <div className="flex justify-between">
                <span className="font-medium">Logo PEMDA (Kop Kiri):</span>
                <span className={`font-bold px-1.5 py-0.5 rounded text-[10px] ${logoPemda ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-100 text-slate-500'}`}>
                  {logoPemda ? 'Tersimpan' : 'Belum Ada'}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="font-medium">Logo Sekolah (Kop Kanan):</span>
                <span className={`font-bold px-1.5 py-0.5 rounded text-[10px] ${logoSekolah ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-100 text-slate-500'}`}>
                  {logoSekolah ? 'Tersimpan' : 'Belum Ada'}
                </span>
              </div>
            </div>
          </div>

          {/* Device Transfer Instructions Card */}
          <div className="bg-slate-900 text-slate-300 rounded-2xl p-6 space-y-5">
            <div className="flex items-center space-x-2 border-b border-slate-800 pb-3">
              <HelpCircle size={18} className="text-blue-400" />
              <h4 className="font-sans font-bold text-sm text-white">Panduan Pindah Komputer/HP</h4>
            </div>

            <div className="space-y-4 text-xs leading-relaxed">
              <div className="flex items-start space-x-3">
                <div className="w-5 h-5 bg-blue-500/20 text-blue-400 rounded-full flex items-center justify-center font-bold text-[10px] shrink-0 mt-0.5">
                  1
                </div>
                <p>
                  <strong className="text-white block font-sans mb-0.5">Lakukan Cadangan</strong>
                  Klik tombol <span className="text-indigo-400 font-bold">"Ekspor File Cadangan"</span> di komputer lama Anda untuk mendapatkan file .json yang memuat seluruh data.
                </p>
              </div>

              <div className="flex items-start space-x-3">
                <div className="w-5 h-5 bg-blue-500/20 text-blue-400 rounded-full flex items-center justify-center font-bold text-[10px] shrink-0 mt-0.5">
                  2
                </div>
                <p>
                  <strong className="text-white block font-sans mb-0.5">Pindahkan File</strong>
                  Kirim file tersebut ke komputer baru Anda via flashdisk, e-mail, Google Drive, atau pesan WhatsApp Web.
                </p>
              </div>

              <div className="flex items-start space-x-3">
                <div className="w-5 h-5 bg-blue-500/20 text-blue-400 rounded-full flex items-center justify-center font-bold text-[10px] shrink-0 mt-0.5">
                  3
                </div>
                <p>
                  <strong className="text-white block font-sans mb-0.5">Pulihkan di Device Baru</strong>
                  Buka aplikasi ini di komputer baru, masuk ke menu ini, lalu klik <span className="text-indigo-400 font-bold">"Impor File Cadangan"</span> dan pilih file tersebut. Data Anda langsung kembali utuh!
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
