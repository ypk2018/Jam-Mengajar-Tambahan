/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef } from 'react';
import { 
  Plus, 
  Search, 
  Edit, 
  Trash2, 
  X, 
  Users, 
  UserPlus,
  FileSpreadsheet,
  Download,
  BookOpen,
  Briefcase,
  Clock,
  AlertTriangle,
  CheckCircle2,
  Upload,
  Info
} from 'lucide-react';
import { 
  Teacher, 
  TeacherStatus, 
  Subject, 
  ClassRoom, 
  TeachingAssignment, 
  AdditionalTask, 
  AcademicSettings 
} from '../types';
import * as XLSX from 'xlsx';

interface GuruManagerProps {
  teachers: Teacher[];
  subjects: Subject[];
  classes: ClassRoom[];
  assignments: TeachingAssignment[];
  additionalTasks: AdditionalTask[];
  academicSettings: AcademicSettings;
  onAddTeacher: (teacher: Teacher) => void;
  onUpdateTeacher: (teacher: Teacher) => void;
  onDeleteTeacher: (id: string) => void;
  onBulkImport: (
    newTeachers: Teacher[],
    newAssignments: TeachingAssignment[],
    newTasks: AdditionalTask[],
    newSubjects?: Subject[],
    newClasses?: ClassRoom[]
  ) => void;
  onSyncAssignmentsAndTasks: (
    teacherId: string,
    newAssignments: TeachingAssignment[],
    newTasks: AdditionalTask[]
  ) => void;
}

const EMPTY_TEACHER: Omit<Teacher, 'id'> = {
  name: '',
  nip: '',
  golongan: '-',
  status: 'Honorer',
  bidang_studi: ''
};

interface FormAssignment {
  id?: string;
  subject_id: string;
  class_id: string;
  hours_per_week: number;
}

interface FormTask {
  id?: string;
  task_name: string;
  hours_equivalent: number;
  task_description?: string;
}

export default function GuruManager({
  teachers,
  subjects,
  classes,
  assignments,
  additionalTasks,
  academicSettings,
  onAddTeacher,
  onUpdateTeacher,
  onDeleteTeacher,
  onBulkImport,
  onSyncAssignmentsAndTasks
}: GuruManagerProps) {
  const [search, setSearch] = useState('');
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  
  // Advanced Form states for manual additions/edits
  const [formData, setFormData] = useState<Omit<Teacher, 'id'>>(EMPTY_TEACHER);
  const [localAssignments, setLocalAssignments] = useState<FormAssignment[]>([]);
  const [localTasks, setLocalTasks] = useState<FormTask[]>([]);
  const [formErrorMsg, setFormErrorMsg] = useState<string | null>(null);

  // Excel / CSV Upload states
  const [isImportModalOpen, setIsImportModalOpen] = useState(false);
  const [isDragging, setIsDragging] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [importPreview, setImportPreview] = useState<{
    teachers: Teacher[];
    assignments: TeachingAssignment[];
    tasks: AdditionalTask[];
    subjects: Subject[];
    classes: ClassRoom[];
  } | null>(null);
  const [importError, setImportError] = useState<string | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Filtered teachers
  const filteredTeachers = teachers.filter(t => {
    const matchesSearch = t.name.toLowerCase().includes(search.toLowerCase()) || 
                          t.nip.includes(search) || 
                          t.bidang_studi.toLowerCase().includes(search.toLowerCase());
    const matchesStatus = filterStatus === 'all' ? true : t.status === filterStatus;
    return matchesSearch && matchesStatus;
  });

  const openAddModal = () => {
    setEditingId(null);
    setFormErrorMsg(null);
    setFormData(EMPTY_TEACHER);
    setLocalAssignments([]);
    setLocalTasks([]);
    setIsModalOpen(true);
  };

  const openEditModal = (teacher: Teacher) => {
    setEditingId(teacher.id);
    setFormErrorMsg(null);
    setFormData({
      name: teacher.name,
      nip: teacher.nip,
      golongan: teacher.golongan,
      status: teacher.status,
      bidang_studi: teacher.bidang_studi
    });

    // Extract current assignments for this teacher
    const teacherAssignments = assignments.filter(a => a.teacher_id === teacher.id);
    setLocalAssignments(teacherAssignments.map(a => ({
      id: a.id,
      subject_id: a.subject_id,
      class_id: a.class_id,
      hours_per_week: a.hours_per_week
    })));

    // Extract current additional tasks for this teacher (for active year)
    const teacherTasks = additionalTasks.filter(
      t => t.teacher_id === teacher.id && t.academic_year === academicSettings.academic_year
    );
    setLocalTasks(teacherTasks.map(t => ({
      id: t.id,
      task_name: t.task_name,
      hours_equivalent: t.hours_equivalent,
      task_description: t.task_description || ''
    })));

    setIsModalOpen(true);
  };

  const handleAddAssignmentRow = () => {
    setLocalAssignments([
      ...localAssignments,
      {
        subject_id: subjects[0]?.id || '',
        class_id: classes[0]?.id || '',
        hours_per_week: 4
      }
    ]);
  };

  const handleRemoveAssignmentRow = (index: number) => {
    setLocalAssignments(localAssignments.filter((_, i) => i !== index));
  };

  const handleAssignmentRowChange = (index: number, fields: Partial<FormAssignment>) => {
    setLocalAssignments(localAssignments.map((row, i) => i === index ? { ...row, ...fields } : row));
  };

  const handleAddTaskRow = () => {
    setLocalTasks([
      ...localTasks,
      {
        task_name: '',
        hours_equivalent: 6,
        task_description: ''
      }
    ]);
  };

  const handleRemoveTaskRow = (index: number) => {
    setLocalTasks(localTasks.filter((_, i) => i !== index));
  };

  const handleTaskRowChange = (index: number, fields: Partial<FormTask>) => {
    setLocalTasks(localTasks.map((row, i) => i === index ? { ...row, ...fields } : row));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanName = formData.name.trim();

    if (!cleanName) {
      setFormErrorMsg('Nama Lengkap Guru tidak boleh kosong.');
      return;
    }

    // NIP Validation if PNS/PPPK
    if ((formData.status === 'PNS' || formData.status === 'PPPK') && !formData.nip.trim()) {
      setFormErrorMsg(`NIP wajib diisi untuk guru berstatus ${formData.status}.`);
      return;
    }

    const cleanNip = formData.nip.trim();
    if (cleanNip) {
      // Must only contain digits, spaces, hyphens, or dots
      const strippedNip = cleanNip.replace(/[\s\.\-]/g, '');
      if (!/^\d+$/.test(strippedNip)) {
        setFormErrorMsg('Format NIP tidak valid. NIP hanya boleh berisi angka.');
        return;
      }

      // Must be unique
      const isNipDuplicate = teachers.some(
        t => t.nip.trim() === cleanNip && t.id !== editingId
      );
      if (isNipDuplicate) {
        setFormErrorMsg(`Guru dengan NIP "${cleanNip}" sudah terdaftar.`);
        return;
      }
    }

    // Assignments Validation
    for (let i = 0; i < localAssignments.length; i++) {
      const la = localAssignments[i];
      if (!la.subject_id) {
        setFormErrorMsg(`Silakan pilih Mata Pelajaran pada baris Pembagian Jam ke-${i + 1}.`);
        return;
      }
      if (!la.class_id) {
        setFormErrorMsg(`Silakan pilih Rombel/Kelas pada baris Pembagian Jam ke-${i + 1}.`);
        return;
      }
      const hrs = Number(la.hours_per_week);
      if (isNaN(hrs) || hrs < 0 || hrs > 100) {
        setFormErrorMsg(`Beban mengajar (JP) harus berupa angka antara 0 sampai 100 pada baris ke-${i + 1}.`);
        return;
      }
    }

    // Check duplicate combinations of subject + class in localAssignments
    const assignmentKeys = localAssignments.map(la => `${la.subject_id}_${la.class_id}`);
    const uniqueAssignmentKeys = new Set(assignmentKeys);
    if (assignmentKeys.length !== uniqueAssignmentKeys.size) {
      setFormErrorMsg('Terdeteksi duplikasi pembagian jam: Anda tidak boleh menugaskan Guru yang sama pada Mata Pelajaran dan Kelas Rombel yang persis sama lebih dari sekali.');
      return;
    }

    // Tasks Validation
    for (let i = 0; i < localTasks.length; i++) {
      const lt = localTasks[i];
      if (!lt.task_name.trim()) {
        setFormErrorMsg(`Nama Tugas Tambahan tidak boleh kosong pada baris ke-${i + 1}.`);
        return;
      }
      const hrs = Number(lt.hours_equivalent);
      if (isNaN(hrs) || hrs < 0 || hrs > 100) {
        setFormErrorMsg(`Ekuivalen Jam (JP) harus berupa angka antara 0 sampai 100 pada baris Tugas Tambahan ke-${i + 1}.`);
        return;
      }
    }

    const teacherId = editingId || 'teacher_' + Date.now().toString();
    const teacherData: Teacher = {
      id: teacherId,
      name: cleanName,
      nip: cleanNip,
      golongan: formData.golongan,
      status: formData.status,
      bidang_studi: formData.bidang_studi.trim()
    };

    if (editingId) {
      onUpdateTeacher(teacherData);
    } else {
      onAddTeacher(teacherData);
    }

    // Prepare assignments and tasks lists
    const finalAssignments: TeachingAssignment[] = localAssignments.map((la, idx) => ({
      id: la.id || `assign_${teacherId}_${Date.now()}_${idx}`,
      teacher_id: teacherId,
      subject_id: la.subject_id,
      class_id: la.class_id,
      hours_per_week: Number(la.hours_per_week) || 0,
      academic_year: academicSettings.academic_year,
      semester: academicSettings.semester
    }));

    const finalTasks: AdditionalTask[] = localTasks.map((lt, idx) => ({
      id: lt.id || `task_${teacherId}_${Date.now()}_${idx}`,
      teacher_id: teacherId,
      task_name: lt.task_name.trim(),
      hours_equivalent: Number(lt.hours_equivalent) || 0,
      task_description: lt.task_description.trim(),
      academic_year: academicSettings.academic_year
    }));

    // Perform state synchronization
    onSyncAssignmentsAndTasks(teacherId, finalAssignments, finalTasks);
    setIsModalOpen(false);
  };

  const handleDelete = (id: string, name: string) => {
    if (window.confirm(`Apakah Anda yakin ingin menghapus guru "${name}"? Tindakan ini juga akan menghapus seluruh pembagian jam dan tugas tambahan terkait.`)) {
      onDeleteTeacher(id);
    }
  };

  // ================= EXCEL BULK IMPORT LOGIC =================

  const downloadTemplate = () => {
    const csvContent = "data:text/csv;charset=utf-8," 
      + "Nama,NIP,Golongan,Status,Bidang Studi,Mapel Diajar,Tugas Tambahan,Jam Tugas Tambahan\n"
      + "Drs. Yusuf Wally,196803201995121003,IV/b,PNS,PPKn,PPKn (VII-A: 3 JP); PPKn (VII-B: 3 JP),Wakil Kepala Sekolah; Wali Kelas VII-A,12; 6\n"
      + "Mariana Ondikeleuw S.Pd,197509182006042011,III/d,PNS,Matematika,Matematika (VII-C: 5 JP); Matematika (VIII-A: 5 JP),Kepala Laboratorium,6\n"
      + "Lydia Pekei S.Pd,-,-,Honorer,Bahasa Inggris,Bahasa Inggris (IX-A: 4 JP),Wali Kelas IX-A,6\n";
    
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", "template_import_guru_smp7.csv");
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files?.[0];
    if (file) {
      processFile(file);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      processFile(file);
    }
  };

  const processFile = (file: File) => {
    setImportError(null);
    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const data = event.target?.result;
        const workbook = XLSX.read(data, { type: 'binary' });
        const firstSheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[firstSheetName];
        const jsonData = XLSX.utils.sheet_to_json<any>(worksheet);

        if (jsonData.length === 0) {
          setImportError("File kosong atau tidak memiliki baris data.");
          return;
        }

        parseExcelData(jsonData);
      } catch (err) {
        console.error(err);
        setImportError("Gagal membaca file. Pastikan file berformat .csv, .xls, atau .xlsx yang valid.");
      }
    };
    reader.readAsBinaryString(file);
  };

  const parseExcelData = (rows: any[]) => {
    const parsedTeachers: Teacher[] = [];
    const parsedAssignments: TeachingAssignment[] = [];
    const parsedTasks: AdditionalTask[] = [];

    // Local mutable lists for in-memory mapping to prevent double inserts of newly created items
    const tempSubjects = [...subjects];
    const tempClasses = [...classes];

    rows.forEach((row, index) => {
      const keys = Object.keys(row);
      const getVal = (aliases: string[]) => {
        const foundKey = keys.find(k => 
          aliases.some(alias => k.toLowerCase().replace(/[\s_-]/g, '').includes(alias))
        );
        return foundKey ? String(row[foundKey]).trim() : '';
      };

      const name = getVal(['nama', 'name', 'fullname']);
      if (!name) return; // Skip row if name is blank

      const nip = getVal(['nip', 'nomorinduk', 'employeeid']);
      const golongan = getVal(['golongan', 'gol', 'pangkat']) || '-';
      
      const statusRaw = getVal(['status', 'kepegawaian', 'statuspegawai']).toUpperCase();
      let status: TeacherStatus = 'Honorer';
      if (statusRaw.includes('PNS')) status = 'PNS';
      else if (statusRaw.includes('PPK') || statusRaw.includes('P3K')) status = 'PPPK';
      else if (statusRaw.includes('HONOR') || statusRaw.includes('GTT') || statusRaw.includes('BANTU')) status = 'Honorer';

      const bidang_studi = getVal(['bidangstudi', 'studi', 'keahlian', 'mapelutama', 'subject']) || 'Umum';

      // Generate ID
      const teacherId = `imported_teacher_${Date.now()}_${index}`;
      
      parsedTeachers.push({
        id: teacherId,
        name,
        nip,
        golongan,
        status,
        bidang_studi
      });

      // Parse multi-subject mengajar
      // Example cell value: "Matematika (VII-A: 4 JP); IPA (VIII-B: 5 JP)" or "PPKn Kelas VII-A: 3"
      const mapelDiajarStr = getVal(['mapeldiajar', 'matapelajaran', 'mengajar', 'jamdiajar', 'pembagianjam']);
      if (mapelDiajarStr) {
        // split by comma or semicolon
        const mapelParts = mapelDiajarStr.split(/[,;]+/);
        mapelParts.forEach(part => {
          let subjectName = '';
          let className = '';
          let jpVal = 4; // default hours

          // Extract Class tags e.g. "VII-A", "VIII-C", "IX-3"
          const classRegex = /(VII|VIII|IX)-[A-Ga-g0-9]/i;
          const classMatch = part.match(classRegex);

          if (classMatch) {
            className = 'Kelas ' + classMatch[0].toUpperCase();
            
            // subject name is anything before class name, cleaned
            const classIdx = part.indexOf(classMatch[0]);
            subjectName = part.substring(0, classIdx)
              .replace(/[\(\[\-\s:]+$/, '')
              .replace(/kelas/i, '')
              .trim();

            // hours is any digit after class name
            const postClass = part.substring(classIdx + classMatch[0].length);
            const hoursMatch = postClass.match(/\d+/);
            if (hoursMatch) {
              jpVal = parseInt(hoursMatch[0]);
            }
          } else {
            // No class matched, e.g. "Matematika: 4" or just "Matematika"
            const parts2 = part.split(/[:\-]+/);
            if (parts2.length >= 2) {
              subjectName = parts2[0].trim();
              const parsedHrs = parseInt(parts2[1]);
              if (!isNaN(parsedHrs)) jpVal = parsedHrs;
            } else {
              subjectName = part.trim();
            }
            className = 'Kelas VII-A'; // fallback class
          }

          if (subjectName) {
            // Find or create subject
            let matchedSubject = tempSubjects.find(s => 
              s.name.toLowerCase() === subjectName.toLowerCase() || 
              s.code.toLowerCase() === subjectName.toLowerCase()
            );
            let subjectId = '';
            if (matchedSubject) {
              subjectId = matchedSubject.id;
            } else {
              subjectId = `sub_auto_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
              const code = subjectName.substring(0, 3).toUpperCase() + '-' + Math.floor(10 + Math.random() * 90);
              tempSubjects.push({
                id: subjectId,
                code,
                name: subjectName,
                kurikulum: 'Kurikulum Merdeka'
              });
            }

            // Find or create class
            let matchedClass = tempClasses.find(c => c.name.toLowerCase() === className.toLowerCase());
            let classId = '';
            if (matchedClass) {
              classId = matchedClass.id;
            } else {
              classId = `class_auto_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
              const grade = className.includes('VIII') ? 'VIII' : className.includes('IX') ? 'IX' : 'VII';
              tempClasses.push({
                id: classId,
                name: className,
                tingkat: grade
              });
            }

            parsedAssignments.push({
              id: `imported_assign_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
              teacher_id: teacherId,
              subject_id: subjectId,
              class_id: classId,
              hours_per_week: jpVal,
              academic_year: academicSettings.academic_year,
              semester: academicSettings.semester
            });
          }
        });
      }

      // Parse multiple Tugas Tambahan
      // Format: "Wakil Kepala Sekolah (12 JP); Wali Kelas VII-A (6 JP)"
      const tugasStr = getVal(['tugastambahan', 'jabatan', 'tugasfungsional']);
      const jpTugasStr = getVal(['jamtugastambahan', 'jptugastambahan', 'ekuivalen', 'jamekuivalen']);

      if (tugasStr) {
        const taskParts = tugasStr.split(/[,;]+/);
        const taskHoursParts = jpTugasStr ? jpTugasStr.split(/[,;]+/) : [];

        taskParts.forEach((taskPart, tIdx) => {
          let taskName = '';
          let hoursEquivalent = 6; // default

          // Check for embedded hours like "Wakil Kepala Sekolah (12)"
          const embeddedMatch = taskPart.match(/\d+/);
          if (embeddedMatch && taskPart.includes('(')) {
            hoursEquivalent = parseInt(embeddedMatch[0]);
            taskName = taskPart.replace(/\([\s\S]*\)/, '').trim();
          } else if (taskPart.includes(':')) {
            const parts2 = taskPart.split(':');
            taskName = parts2[0].trim();
            const parsedHrs = parseInt(parts2[1]);
            if (!isNaN(parsedHrs)) hoursEquivalent = parsedHrs;
          } else {
            taskName = taskPart.trim();
            if (taskHoursParts[tIdx]) {
              const parsedHrs = parseInt(taskHoursParts[tIdx].trim());
              if (!isNaN(parsedHrs)) hoursEquivalent = parsedHrs;
            } else {
              // Guess standard equivalent hours based on keywords
              const lowerTask = taskName.toLowerCase();
              if (lowerTask.includes('wakil') || lowerTask.includes('wakasek')) hoursEquivalent = 12;
              else if (lowerTask.includes('kepala sekolah') || lowerTask.includes('kepsek')) hoursEquivalent = 12;
              else if (lowerTask.includes('wali kelas') || lowerTask.includes('walas')) hoursEquivalent = 6;
              else if (lowerTask.includes('perpustakaan') || lowerTask.includes('pustaka')) hoursEquivalent = 6;
              else if (lowerTask.includes('laboratorium') || lowerTask.includes('lab')) hoursEquivalent = 6;
            }
          }

          if (taskName) {
            parsedTasks.push({
              id: `imported_task_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
              teacher_id: teacherId,
              task_name: taskName,
              hours_equivalent: hoursEquivalent,
              academic_year: academicSettings.academic_year
            });
          }
        });
      }
    });

    setImportPreview({
      teachers: parsedTeachers,
      assignments: parsedAssignments,
      tasks: parsedTasks,
      subjects: tempSubjects,
      classes: tempClasses
    });
  };

  const triggerImportConfirm = () => {
    if (!importPreview) return;
    
    // Extract new subjects and classes that don't already exist
    const newSubjects = importPreview.subjects.filter(
      s => !subjects.some(existing => existing.id === s.id)
    );
    const newClasses = importPreview.classes.filter(
      c => !classes.some(existing => existing.id === c.id)
    );

    onBulkImport(
      importPreview.teachers, 
      importPreview.assignments, 
      importPreview.tasks,
      newSubjects,
      newClasses
    );
    
    // Close modals
    setImportPreview(null);
    setIsImportModalOpen(false);
    
    // Set toast notification
    setToastMessage(`Sukses mengimport ${importPreview.teachers.length} Guru beserta pembagian jam & tugas tambahan masing-masing!`);
    setTimeout(() => {
      setToastMessage(null);
    }, 5000);
  };

  return (
    <div className="space-y-6 animate-fade-in relative">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 bg-slate-900 text-white text-xs py-3.5 px-5 rounded-2xl border border-slate-800 shadow-2xl flex items-center space-x-3 animate-bounce-in font-medium">
          <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 shrink-0 shadow-lg shadow-emerald-500/50" />
          <span>{toastMessage}</span>
          <button 
            type="button" 
            onClick={() => setToastMessage(null)}
            className="text-slate-400 hover:text-white transition p-1"
          >
            <X size={14} className="stroke-[2.5]" />
          </button>
        </div>
      )}

      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-display font-bold text-3xl text-slate-950 tracking-tight">Manajemen Data Guru</h1>
          <p className="text-slate-500 text-sm mt-1">Daftar guru pendidik SMP Negeri 7 Sentani, rincian kepegawaian, mapel diajar, dan tugas tambahan.</p>
        </div>
        <div className="flex items-center space-x-2.5 shrink-0">
          <button
            onClick={() => {
              setImportPreview(null);
              setImportError(null);
              setIsImportModalOpen(true);
            }}
            className="bg-white hover:bg-slate-50 text-slate-700 border border-slate-200 font-semibold px-4 py-2.5 rounded-xl shadow-xs flex items-center justify-center space-x-2 transition duration-200 text-sm"
          >
            <FileSpreadsheet size={18} className="text-emerald-600 stroke-[2.2]" />
            <span>Upload Excel / CSV</span>
          </button>
          
          <button
            id="btn-add-teacher"
            onClick={openAddModal}
            className="bg-blue-600 hover:bg-blue-700 text-white font-semibold px-4 py-2.5 rounded-xl shadow-lg shadow-blue-500/15 flex items-center justify-center space-x-2 transition duration-200 text-sm"
          >
            <UserPlus size={18} className="stroke-[2.5]" />
            <span>Tambah Guru Baru</span>
          </button>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white p-4 rounded-xl shadow-xs border border-slate-200 flex flex-col md:flex-row gap-4 items-center justify-between">
        {/* Search Input */}
        <div className="relative w-full md:w-96">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
          <input
            type="text"
            placeholder="Cari guru, NIP, atau bidang studi..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-11 pr-4 py-2 text-sm text-slate-880 placeholder-slate-400 focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500 transition"
          />
        </div>

        {/* Status Filter */}
        <div className="flex items-center space-x-2 w-full md:w-auto">
          <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider shrink-0">Filter Status:</span>
          <div className="flex bg-slate-100 p-1 rounded-xl border border-slate-200 w-full sm:w-auto">
            {['all', 'PNS', 'PPPK', 'Honorer'].map((status) => (
              <button
                key={status}
                type="button"
                onClick={() => setFilterStatus(status)}
                className={`flex-1 sm:flex-none px-3.5 py-1 text-xs font-medium rounded-lg transition ${
                  filterStatus === status 
                    ? 'bg-white text-slate-900 shadow-xs font-bold' 
                    : 'text-slate-500 hover:text-slate-900'
                }`}
              >
                {status === 'all' ? 'Semua' : status}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Teachers Table Card */}
      <div className="bg-white rounded-xl shadow-xs border border-slate-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs md:text-sm">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-slate-500 uppercase font-bold tracking-widest text-[10px]">
                <th className="py-4 px-6">Nama Guru</th>
                <th className="py-4 px-6">NIP / Golongan</th>
                <th className="py-4 px-6">Status Pegawai</th>
                <th className="py-4 px-6">Mapel Diajar (Beban JP)</th>
                <th className="py-4 px-6">Tugas Tambahan</th>
                <th className="py-4 px-6 text-right">Aksi</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700">
              {filteredTeachers.length > 0 ? (
                filteredTeachers.map((teacher) => {
                  const teacherAssignments = assignments.filter(a => a.teacher_id === teacher.id);
                  const teacherTasks = additionalTasks.filter(
                    t => t.teacher_id === teacher.id && t.academic_year === academicSettings.academic_year
                  );

                  return (
                    <tr key={teacher.id} className="hover:bg-slate-50/20 transition duration-150">
                      <td className="py-4 px-6">
                        <div className="flex items-center space-x-3">
                          <div className="bg-slate-100 text-slate-700 w-10 h-10 rounded-full flex items-center justify-center font-bold text-sm shrink-0 border border-slate-200">
                            {teacher.name.split(' ').filter(n => !n.includes('.')).map(n => n[0]).slice(0, 2).join('') || 'G'}
                          </div>
                          <div>
                            <p className="font-bold text-slate-900 text-sm leading-tight">{teacher.name}</p>
                            <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wide block mt-1">{teacher.bidang_studi}</span>
                          </div>
                        </div>
                      </td>
                      <td className="py-4 px-6">
                        <p className="font-mono font-medium text-slate-800">{teacher.nip || '-'}</p>
                        <span className="text-xs text-slate-400 font-semibold">Gol: <span className="font-mono text-slate-700">{teacher.golongan}</span></span>
                      </td>
                      <td className="py-4 px-6">
                        <span className={`inline-flex px-2.5 py-0.5 rounded text-[10px] font-bold ${
                          teacher.status === 'PNS' ? 'bg-blue-50 text-blue-700 border border-blue-100' :
                          teacher.status === 'PPPK' ? 'bg-cyan-50 text-cyan-700 border border-cyan-100' :
                          'bg-yellow-50 text-yellow-700 border border-yellow-100'
                        }`}>
                          {teacher.status}
                        </span>
                      </td>
                      <td className="py-4 px-6">
                        {teacherAssignments.length > 0 ? (
                          <div className="flex flex-wrap gap-1.5 max-w-xs">
                            {teacherAssignments.map(a => {
                              const s = subjects.find(subj => subj.id === a.subject_id);
                              const c = classes.find(cl => cl.id === a.class_id);
                              return (
                                <span 
                                  key={a.id} 
                                  className="inline-flex items-center space-x-1 bg-slate-50 border border-slate-200 text-slate-700 px-1.5 py-0.5 rounded text-[10px] font-medium"
                                >
                                  <span>{s?.name || 'Mapel'}:</span>
                                  <span className="font-bold text-blue-600">{c?.name.replace('Kelas ', '') || 'Rombel'}</span>
                                  <span className="text-[9px] text-slate-400 font-bold font-mono">({a.hours_per_week}JP)</span>
                                </span>
                              );
                            })}
                          </div>
                        ) : (
                          <span className="text-slate-400 text-xs italic">Belum mengajar</span>
                        )}
                      </td>
                      <td className="py-4 px-6">
                        {teacherTasks.length > 0 ? (
                          <div className="flex flex-col gap-1">
                            {teacherTasks.map(t => (
                              <div key={t.id} className="flex items-center space-x-1.5 text-xs text-slate-700">
                                <span className="w-1.5 h-1.5 rounded-full bg-blue-500 shrink-0" />
                                <span className="font-semibold">{t.task_name}</span>
                                <span className="text-[10px] text-slate-400 font-mono font-bold">({t.hours_equivalent} JP)</span>
                              </div>
                            ))}
                          </div>
                        ) : (
                          <span className="text-slate-400 text-xs">-</span>
                        )}
                      </td>
                      <td className="py-4 px-6 text-right">
                        <div className="flex items-center justify-end space-x-2">
                          <button
                            onClick={() => openEditModal(teacher)}
                            className="p-1.5 hover:bg-slate-100 rounded-lg text-slate-500 hover:text-slate-900 transition"
                            title="Edit Guru"
                          >
                            <Edit size={16} />
                          </button>
                          <button
                            onClick={() => handleDelete(teacher.id, teacher.name)}
                            className="p-1.5 hover:bg-red-50 rounded-lg text-slate-400 hover:text-red-500 transition"
                            title="Hapus Guru"
                          >
                            <Trash2 size={16} />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              ) : (
                <tr>
                  <td colSpan={6} className="py-12 text-center text-slate-400 font-medium">
                    Tidak ada data guru yang cocok dengan filter atau pencarian Anda.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* ================= ADD/EDIT TEACHER FORM MODAL ================= */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-slate-950/40 backdrop-blur-xs flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl w-full max-w-2xl shadow-2xl border border-slate-100 overflow-hidden animate-zoom-in flex flex-col max-h-[90vh]">
            {/* Modal Header */}
            <div className="px-6 py-5 border-b border-slate-200 flex justify-between items-center bg-slate-50">
              <h2 className="font-display font-bold text-lg text-slate-900">
                {editingId ? 'Edit Data Lengkap Guru' : 'Tambah Guru Baru'}
              </h2>
              <button 
                onClick={() => setIsModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 hover:bg-slate-200/50 p-1.5 rounded-lg transition"
              >
                <X size={18} />
              </button>
            </div>

            {/* Modal Body / Scrollable Form */}
            <form onSubmit={handleSubmit} className="p-6 overflow-y-auto space-y-6 flex-1">
              {/* Error Message */}
              {formErrorMsg && (
                <div className="bg-red-50 text-red-700 text-xs p-3.5 rounded-xl border border-red-100 flex items-center justify-between font-medium">
                  <span>{formErrorMsg}</span>
                  <button 
                    type="button" 
                    onClick={() => setFormErrorMsg(null)}
                    className="text-red-400 hover:text-red-600 transition p-1 rounded"
                  >
                    <X size={14} className="stroke-[2.5]" />
                  </button>
                </div>
              )}
              
              {/* SECTION 1: IDENTITAS GURU */}
              <div className="space-y-4">
                <div className="flex items-center space-x-2 border-b border-slate-100 pb-1.5">
                  <Users size={16} className="text-blue-600" />
                  <h3 className="text-xs font-bold text-slate-500 uppercase tracking-wider">Identitas Pegawai Pendidik</h3>
                </div>

                {/* Nama */}
                <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1.5">Nama Lengkap & Gelar</label>
                  <input
                    type="text"
                    required
                    placeholder="Contoh: Drs. Yusuf Wally"
                    value={formData.name}
                    onChange={(e) => setFormData({...formData, name: e.target.value})}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 text-sm text-slate-800 focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500 transition"
                  />
                </div>

                {/* NIP & Golongan */}
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1.5">NIP (Optional)</label>
                    <input
                      type="text"
                      placeholder="19680320..."
                      value={formData.nip}
                      onChange={(e) => setFormData({...formData, nip: e.target.value})}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 text-sm text-slate-800 focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500 transition font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1.5">Golongan</label>
                    <input
                      type="text"
                      placeholder="Contoh: IV/b, III/d, atau -"
                      value={formData.golongan}
                      onChange={(e) => setFormData({...formData, golongan: e.target.value})}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 text-sm text-slate-800 focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500 transition font-mono"
                    />
                  </div>
                </div>

                {/* Status & Bidang Studi */}
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1.5">Status Pegawai</label>
                    <select
                      value={formData.status}
                      onChange={(e) => setFormData({...formData, status: e.target.value as TeacherStatus})}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2.5 text-sm text-slate-800 focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500 transition font-medium text-slate-800"
                    >
                      <option value="PNS">PNS</option>
                      <option value="PPPK">PPPK</option>
                      <option value="Honorer">Honorer</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1.5">Bidang Studi Utama</label>
                    <input
                      type="text"
                      required
                      placeholder="Contoh: PPKn, Matematika"
                      value={formData.bidang_studi}
                      onChange={(e) => setFormData({...formData, bidang_studi: e.target.value})}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 text-sm text-slate-800 focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500 transition"
                    />
                  </div>
                </div>
              </div>

              {/* SECTION 2: MAPEL DIAJAR (BISA LEBIH DARI SATU) */}
              <div className="space-y-4 pt-4 border-t border-slate-100">
                <div className="flex items-center justify-between border-b border-slate-100 pb-1.5">
                  <div className="flex items-center space-x-2">
                    <BookOpen size={16} className="text-blue-600" />
                    <h3 className="text-xs font-bold text-slate-500 uppercase tracking-wider">Mata Pelajaran yang Diajar (Bisa Lebih dari 1)</h3>
                  </div>
                  <button
                    type="button"
                    onClick={handleAddAssignmentRow}
                    className="text-xs font-bold text-blue-600 hover:text-blue-700 bg-blue-50 hover:bg-blue-100 px-3 py-1.5 rounded-lg border border-blue-100/50 flex items-center space-x-1 transition"
                  >
                    <Plus size={14} />
                    <span>Tambah Mapel & Rombel</span>
                  </button>
                </div>

                {localAssignments.length > 0 ? (
                  <div className="space-y-2.5 max-h-56 overflow-y-auto pr-1">
                    {localAssignments.map((row, idx) => (
                      <div key={idx} className="grid grid-cols-12 gap-2.5 items-center bg-slate-50/50 p-2.5 rounded-xl border border-slate-150">
                        {/* Subject */}
                        <div className="col-span-5">
                          <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">Mata Pelajaran</label>
                          <select
                            required
                            value={row.subject_id}
                            onChange={(e) => handleAssignmentRowChange(idx, { subject_id: e.target.value })}
                            className="w-full bg-white border border-slate-200 rounded-lg px-2 py-1.5 text-xs text-slate-800 focus:outline-none focus:ring-1 focus:ring-blue-500"
                          >
                            {subjects.map(s => (
                              <option key={s.id} value={s.id}>{s.name} ({s.code})</option>
                            ))}
                          </select>
                        </div>

                        {/* Class */}
                        <div className="col-span-4">
                          <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">Rombel / Kelas</label>
                          <select
                            required
                            value={row.class_id}
                            onChange={(e) => handleAssignmentRowChange(idx, { class_id: e.target.value })}
                            className="w-full bg-white border border-slate-200 rounded-lg px-2 py-1.5 text-xs text-slate-800 focus:outline-none focus:ring-1 focus:ring-blue-500"
                          >
                            {classes.map(c => (
                              <option key={c.id} value={c.id}>{c.name}</option>
                            ))}
                          </select>
                        </div>

                        {/* Hours */}
                        <div className="col-span-2">
                          <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">Beban JP</label>
                          <input
                            type="number"
                            min="0"
                            max="100"
                            required
                            value={row.hours_per_week}
                            onChange={(e) => handleAssignmentRowChange(idx, { hours_per_week: parseInt(e.target.value) || 0 })}
                            className="w-full bg-white border border-slate-200 rounded-lg px-2 py-1.5 text-xs text-center font-bold text-slate-800 focus:outline-none focus:ring-1 focus:ring-blue-500"
                          />
                        </div>

                        {/* Delete Row */}
                        <div className="col-span-1 text-center pt-4">
                          <button
                            type="button"
                            onClick={() => handleRemoveAssignmentRow(idx)}
                            className="text-red-400 hover:text-red-600 p-1 hover:bg-red-50 rounded-lg transition"
                          >
                            <Trash2 size={16} />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-6 border border-dashed border-slate-200 rounded-xl bg-slate-50/20">
                    <p className="text-xs text-slate-400 font-medium">Belum ada pembagian jam mengajar langsung dari form ini.</p>
                    <button
                      type="button"
                      onClick={handleAddAssignmentRow}
                      className="mt-2 text-xs font-bold text-blue-600 hover:underline"
                    >
                      + Tambah Sekarang
                    </button>
                  </div>
                )}
              </div>

              {/* SECTION 3: TUGAS TAMBAHAN (BISA LEBIH DARI SATU + TEMPAT JAM NYA MASING-MASING) */}
              <div className="space-y-4 pt-4 border-t border-slate-100">
                <div className="flex items-center justify-between border-b border-slate-100 pb-1.5">
                  <div className="flex items-center space-x-2">
                    <Briefcase size={16} className="text-blue-600" />
                    <h3 className="text-xs font-bold text-slate-500 uppercase tracking-wider">Tugas Tambahan Fungsional (Bisa Lebih dari 1)</h3>
                  </div>
                  <button
                    type="button"
                    onClick={handleAddTaskRow}
                    className="text-xs font-bold text-blue-600 hover:text-blue-700 bg-blue-50 hover:bg-blue-100 px-3 py-1.5 rounded-lg border border-blue-100/50 flex items-center space-x-1 transition"
                  >
                    <Plus size={14} />
                    <span>Tambah Tugas Tambahan</span>
                  </button>
                </div>

                {localTasks.length > 0 ? (
                  <div className="space-y-2.5 max-h-56 overflow-y-auto pr-1">
                    {localTasks.map((row, idx) => (
                      <div key={idx} className="bg-slate-50/50 p-3 rounded-xl border border-slate-150 space-y-2">
                        <div className="grid grid-cols-12 gap-2.5 items-center">
                          {/* Task Name */}
                          <div className="col-span-8">
                            <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">Nama Tugas Tambahan (Jabatan)</label>
                            <input
                              type="text"
                              required
                              placeholder="Contoh: Wakil Kepala Sekolah, Kepala Perpustakaan"
                              value={row.task_name}
                              onChange={(e) => handleTaskRowChange(idx, { task_name: e.target.value })}
                              className="w-full bg-white border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs text-slate-800 focus:outline-none focus:ring-1 focus:ring-blue-500"
                            />
                          </div>

                          {/* Equivalent Hours */}
                          <div className="col-span-3">
                            <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">Ekuivalen JP</label>
                            <div className="flex items-center space-x-2">
                              <input
                                type="number"
                                min="0"
                                max="100"
                                required
                                value={row.hours_equivalent}
                                onChange={(e) => handleTaskRowChange(idx, { hours_equivalent: parseInt(e.target.value) || 0 })}
                                className="w-full bg-white border border-slate-200 rounded-lg px-2 py-1.5 text-xs text-center font-bold text-slate-800 focus:outline-none focus:ring-1 focus:ring-blue-500"
                              />
                              <span className="text-[10px] font-bold text-slate-400">JP</span>
                            </div>
                          </div>

                          {/* Delete Row */}
                          <div className="col-span-1 text-center">
                            <button
                              type="button"
                              onClick={() => handleRemoveTaskRow(idx)}
                              className="text-red-400 hover:text-red-600 p-1 hover:bg-red-50 rounded-lg transition"
                            >
                              <Trash2 size={16} />
                            </button>
                          </div>
                        </div>

                        {/* Description field */}
                        <div>
                          <input
                            type="text"
                            placeholder="Deskripsi tugas singkat (misal: S.K. No 421/109)..."
                            value={row.task_description}
                            onChange={(e) => handleTaskRowChange(idx, { task_description: e.target.value })}
                            className="w-full bg-white border border-slate-150 rounded-lg px-2.5 py-1 text-[11px] text-slate-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-6 border border-dashed border-slate-200 rounded-xl bg-slate-50/20">
                    <p className="text-xs text-slate-400 font-medium">Belum ada penugasan tugas tambahan dari form ini.</p>
                    <button
                      type="button"
                      onClick={handleAddTaskRow}
                      className="mt-2 text-xs font-bold text-blue-600 hover:underline"
                    >
                      + Tambah Sekarang
                    </button>
                  </div>
                )}
              </div>

              {/* Modal Footer Buttons */}
              <div className="pt-4 border-t border-slate-150 flex justify-end space-x-2.5">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 rounded-xl text-xs font-semibold text-slate-600 transition"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-blue-600 hover:bg-blue-700 rounded-xl text-xs font-bold text-white shadow-md shadow-blue-600/10 transition"
                >
                  {editingId ? 'Simpan Perubahan' : 'Simpan Data Guru'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ================= EXCEL/CSV IMPORT MODAL ================= */}
      {isImportModalOpen && (
        <div className="fixed inset-0 bg-slate-950/40 backdrop-blur-xs flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl w-full max-w-3xl shadow-2xl border border-slate-100 overflow-hidden animate-zoom-in flex flex-col max-h-[90vh]">
            {/* Modal Header */}
            <div className="px-6 py-5 border-b border-slate-200 flex justify-between items-center bg-slate-50">
              <div className="flex items-center space-x-2">
                <FileSpreadsheet className="text-emerald-600" size={20} />
                <h2 className="font-display font-bold text-lg text-slate-900">
                  Import Guru Menggunakan Spreadsheet
                </h2>
              </div>
              <button 
                onClick={() => {
                  setIsImportModalOpen(false);
                  setImportPreview(null);
                  setImportError(null);
                }}
                className="text-slate-400 hover:text-slate-600 hover:bg-slate-200/50 p-1.5 rounded-lg transition"
              >
                <X size={18} />
              </button>
            </div>

            <div className="p-6 overflow-y-auto flex-1 space-y-6">
              {/* Template downloader / info instructions */}
              {!importPreview && (
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="col-span-2 space-y-3">
                    <h3 className="text-xs font-bold text-slate-500 uppercase tracking-wider">Format Kolom Spreadsheet</h3>
                    <p className="text-slate-600 text-xs leading-relaxed">
                      Sistem mendukung file **Microsoft Excel (.xlsx, .xls)** atau **CSV (.csv)**. Hubungkan data secara otomatis dengan membuat nama kolom berikut:
                    </p>
                    <ul className="text-slate-600 text-xs space-y-1.5 list-disc pl-5">
                      <li>**Nama**: Nama Lengkap & Gelar pendidik (contoh: *Drs. Yusuf Wally*)</li>
                      <li>**NIP**: NIP 18-Digit (*19680320...*) atau kosongkan jika honorer</li>
                      <li>**Status**: PNS, PPPK, atau Honorer</li>
                      <li>**Bidang Studi**: Keahlian Utama (*PPKn*)</li>
                      <li>**Mapel Diajar**: Mapel, kelas, & jam, pisahkan titik koma (`;`). Contoh: <br/><span className="text-blue-600 font-mono text-[11px] block mt-0.5">PPKn (VII-A: 3 JP); PPKn (VII-B: 3 JP)</span></li>
                      <li>**Tugas Tambahan**: Nama-nama tugas tambahan dipisahkan koma (*Wakil Kepala Sekolah; Wali Kelas VII-A*)</li>
                      <li>**Jam Tugas Tambahan**: JP ekuivalen masing-masing tugas tambahan (*12; 6*)</li>
                    </ul>
                  </div>

                  <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 flex flex-col justify-between items-center text-center">
                    <div className="space-y-2">
                      <Download size={32} className="text-blue-600 mx-auto" />
                      <h4 className="text-xs font-bold text-slate-800">Gunakan Template Resmi</h4>
                      <p className="text-[11px] text-slate-500">Unduh draf CSV terstruktur dengan data contoh untuk meminimalkan error.</p>
                    </div>
                    <button
                      onClick={downloadTemplate}
                      className="mt-3 w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-1.5 rounded-lg text-xs flex items-center justify-center space-x-1.5 transition"
                    >
                      <Download size={14} />
                      <span>Unduh Template CSV</span>
                    </button>
                  </div>
                </div>
              )}

              {/* Drag and Drop Zone */}
              {!importPreview && (
                <div
                  onDragOver={handleDragOver}
                  onDragLeave={handleDragLeave}
                  onDrop={handleDrop}
                  onClick={() => fileInputRef.current?.click()}
                  className={`border-2 border-dashed rounded-2xl p-8 text-center cursor-pointer transition duration-150 ${
                    isDragging 
                      ? 'border-blue-500 bg-blue-50/50' 
                      : 'border-slate-250 hover:border-blue-500 hover:bg-slate-50/30'
                  }`}
                >
                  <input
                    type="file"
                    ref={fileInputRef}
                    onChange={handleFileChange}
                    accept=".xlsx, .xls, .csv"
                    className="hidden"
                  />
                  <div className="space-y-2 max-w-xs mx-auto">
                    <Upload size={36} className="text-slate-400 mx-auto" />
                    <p className="text-sm font-bold text-slate-800">Seret & Lepas Spreadsheet Anda</p>
                    <p className="text-xs text-slate-500">Atau <span className="text-blue-600 font-semibold underline">Pilih file dari komputer</span></p>
                    <p className="text-[10px] text-slate-400">Mendukung XLS, XLSX, dan CSV</p>
                  </div>
                </div>
              )}

              {/* Alert Error */}
              {importError && (
                <div className="p-3 bg-red-50 text-red-600 text-xs font-semibold rounded-xl border border-red-100 flex items-center space-x-2">
                  <AlertTriangle size={16} />
                  <span>{importError}</span>
                </div>
              )}

              {/* ================= DATA IMPORT PREVIEW OVERLAY ================= */}
              {importPreview && (
                <div className="space-y-4">
                  <div className="bg-emerald-50 text-emerald-800 border border-emerald-100 p-4 rounded-xl flex items-center justify-between">
                    <div className="flex items-center space-x-2.5">
                      <CheckCircle2 size={20} className="text-emerald-600" />
                      <div>
                        <h4 className="font-bold text-sm">Spreadsheet Berhasil Terbaca!</h4>
                        <p className="text-xs text-emerald-700/90 mt-0.5">Ditemukan **{importPreview.teachers.length}** profil guru baru yang siap diimport.</p>
                      </div>
                    </div>
                    <button
                      onClick={() => setImportPreview(null)}
                      className="text-xs font-bold text-slate-500 hover:text-slate-700 bg-white border border-slate-250 px-2.5 py-1 rounded-lg"
                    >
                      Reset File
                    </button>
                  </div>

                  <div className="border border-slate-200 rounded-xl overflow-hidden max-h-[50vh] overflow-y-auto">
                    <table className="w-full text-left text-xs">
                      <thead>
                        <tr className="bg-slate-50 border-b border-slate-200 text-slate-500 font-bold uppercase tracking-wider">
                          <th className="p-3">Guru & Bidang Studi</th>
                          <th className="p-3">NIP / Gol</th>
                          <th className="p-3">Status</th>
                          <th className="p-3">Mapel Diajar (Beban JP)</th>
                          <th className="p-3">Tugas Tambahan (JP Ekuivalen)</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100 bg-white">
                        {importPreview.teachers.map((t, idx) => {
                          const tAssigns = importPreview.assignments.filter(a => a.teacher_id === t.id);
                          const tTasks = importPreview.tasks.filter(tk => tk.teacher_id === t.id);

                          return (
                            <tr key={idx} className="hover:bg-slate-50/50">
                              <td className="p-3">
                                <p className="font-bold text-slate-900">{t.name}</p>
                                <span className="text-[10px] text-slate-400 font-bold block">{t.bidang_studi}</span>
                              </td>
                              <td className="p-3">
                                <p className="font-mono font-medium">{t.nip || '-'}</p>
                                <span className="text-[10px] text-slate-400">Gol: {t.golongan}</span>
                              </td>
                              <td className="p-3">
                                <span className="bg-slate-100 text-slate-700 px-1.5 py-0.5 rounded text-[9px] font-bold border border-slate-200">{t.status}</span>
                              </td>
                              <td className="p-3">
                                {tAssigns.length > 0 ? (
                                  <div className="flex flex-col gap-1 max-w-xs">
                                    {tAssigns.map((asg, aIdx) => {
                                      // Search in newly parsed lists
                                      const s = importPreview.subjects.find(sub => sub.id === asg.subject_id) || subjects.find(sub => sub.id === asg.subject_id);
                                      const c = importPreview.classes.find(cl => cl.id === asg.class_id) || classes.find(cl => cl.id === asg.class_id);
                                      return (
                                        <div key={aIdx} className="text-[10px] text-slate-700 font-medium">
                                          <span>{s?.name || 'Mapel'}: </span>
                                          <span className="font-bold text-blue-600">{c?.name || 'Kelas'}</span>
                                          <span className="text-slate-400"> ({asg.hours_per_week} JP)</span>
                                        </div>
                                      );
                                    })}
                                  </div>
                                ) : (
                                  <span className="text-slate-400 italic text-[10px]">-</span>
                                )}
                              </td>
                              <td className="p-3">
                                {tTasks.length > 0 ? (
                                  <div className="flex flex-col gap-1">
                                    {tTasks.map((tsk, tIdx) => (
                                      <div key={tIdx} className="text-[10px] text-slate-700">
                                        <span className="font-semibold">{tsk.task_name}</span>
                                        <span className="text-blue-600 font-bold"> ({tsk.hours_equivalent} JP)</span>
                                      </div>
                                    ))}
                                  </div>
                                ) : (
                                  <span className="text-slate-400 italic text-[10px]">-</span>
                                )}
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}
            </div>

            {/* Modal Footer */}
            <div className="px-6 py-4 border-t border-slate-200 bg-slate-50 flex justify-end space-x-2.5">
              <button
                type="button"
                onClick={() => {
                  setIsImportModalOpen(false);
                  setImportPreview(null);
                  setImportError(null);
                }}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 rounded-xl text-xs font-semibold text-slate-600 transition"
              >
                Batal
              </button>
              
              {importPreview && (
                <button
                  type="button"
                  onClick={triggerImportConfirm}
                  className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 rounded-xl text-xs font-bold text-white shadow-lg shadow-emerald-500/10 transition flex items-center space-x-1"
                >
                  <CheckCircle2 size={14} />
                  <span>Konfirmasi Import ke Database</span>
                </button>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
