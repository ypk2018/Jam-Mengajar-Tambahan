/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  Plus, 
  Search, 
  Edit, 
  Trash2, 
  X, 
  CalendarClock, 
  SlidersHorizontal,
  Bookmark
} from 'lucide-react';
import { TeachingAssignment, Teacher, Subject, ClassRoom, AcademicSettings } from '../types';

interface PembagianJamManagerProps {
  assignments: TeachingAssignment[];
  teachers: Teacher[];
  subjects: Subject[];
  classes: ClassRoom[];
  academicSettings: AcademicSettings;
  onAddAssignment: (assignment: TeachingAssignment) => void;
  onUpdateAssignment: (assignment: TeachingAssignment) => void;
  onDeleteAssignment: (id: string) => void;
}

const EMPTY_ASSIGNMENT = {
  teacher_id: '',
  subject_id: '',
  class_id: '',
  hours_per_week: 4
};

export default function PembagianJamManager({
  assignments,
  teachers,
  subjects,
  classes,
  academicSettings,
  onAddAssignment,
  onUpdateAssignment,
  onDeleteAssignment
}: PembagianJamManagerProps) {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  
  // Filters
  const [filterTeacher, setFilterTeacher] = useState('');
  const [filterClass, setFilterClass] = useState('');
  const [filterSubject, setFilterSubject] = useState('');

  // Form state
  const [formData, setFormData] = useState(EMPTY_ASSIGNMENT);

  // Active assignments for current settings (TA & Semester)
  const currentAssignments = assignments.filter(
    a => a.academic_year === academicSettings.academic_year && a.semester === academicSettings.semester
  );

  // Apply filters
  const filteredAssignments = currentAssignments.filter(a => {
    const matchesTeacher = filterTeacher === '' ? true : a.teacher_id === filterTeacher;
    const matchesClass = filterClass === '' ? true : a.class_id === filterClass;
    const matchesSubject = filterSubject === '' ? true : a.subject_id === filterSubject;
    return matchesTeacher && matchesClass && matchesSubject;
  });

  const openAddModal = () => {
    setEditingId(null);
    setErrorMsg(null);
    setFormData({
      teacher_id: teachers[0]?.id || '',
      subject_id: subjects[0]?.id || '',
      class_id: classes[0]?.id || '',
      hours_per_week: 4
    });
    setIsModalOpen(true);
  };

  const openEditModal = (assignment: TeachingAssignment) => {
    setEditingId(assignment.id);
    setErrorMsg(null);
    setFormData({
      teacher_id: assignment.teacher_id,
      subject_id: assignment.subject_id,
      class_id: assignment.class_id,
      hours_per_week: assignment.hours_per_week
    });
    setIsModalOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.teacher_id || !formData.subject_id || !formData.class_id) {
      setErrorMsg('Mohon lengkapi seluruh kolom formulir.');
      return;
    }

    const hrs = Number(formData.hours_per_week);
    if (isNaN(hrs) || hrs < 0 || hrs > 100) {
       setErrorMsg('Beban mengajar (JP) harus berupa angka antara 0 sampai 100.');
       return;
    }

    // Check if duplicate assignment exists (Same teacher, subject, and class in this semester)
    const isDuplicate = currentAssignments.some(a => 
      a.id !== editingId &&
      a.teacher_id === formData.teacher_id &&
      a.subject_id === formData.subject_id &&
      a.class_id === formData.class_id
    );

    if (isDuplicate) {
      setErrorMsg('Peringatan: Pembagian jam mengajar untuk guru, mata pelajaran, dan kelas yang sama sudah terdaftar di semester ini!');
      return;
    }

    if (editingId) {
      onUpdateAssignment({
        id: editingId,
        teacher_id: formData.teacher_id,
        subject_id: formData.subject_id,
        class_id: formData.class_id,
        hours_per_week: hrs,
        academic_year: academicSettings.academic_year,
        semester: academicSettings.semester
      });
    } else {
      onAddAssignment({
        id: 'assignment_' + Date.now().toString(),
        teacher_id: formData.teacher_id,
        subject_id: formData.subject_id,
        class_id: formData.class_id,
        hours_per_week: hrs,
        academic_year: academicSettings.academic_year,
        semester: academicSettings.semester
      });
    }
    setIsModalOpen(false);
  };

  const handleDelete = (id: string, teacherName: string, subjectName: string, className: string) => {
    if (window.confirm(`Apakah Anda yakin ingin menghapus tugas mengajar "${teacherName}" - "${subjectName}" di "${className}"?`)) {
      onDeleteAssignment(id);
    }
  };

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-display font-bold text-3xl text-slate-950 tracking-tight">Pembagian Jam Mengajar</h1>
          <p className="text-slate-500 text-sm mt-1">
            Distribusikan jam mengajar guru per mata pelajaran dan rombongan belajar.
          </p>
          <div className="inline-flex items-center space-x-2 mt-2 bg-blue-50 text-blue-700 px-3 py-1 rounded-lg border border-blue-100 text-xs font-semibold">
            <span>Aktif: Tahun Pelajaran {academicSettings.academic_year} • Semester {academicSettings.semester}</span>
          </div>
        </div>
        <button
          id="btn-add-assignment"
          onClick={openAddModal}
          className="bg-blue-600 hover:bg-blue-700 text-white font-semibold px-4 py-2.5 rounded-xl shadow-lg shadow-blue-500/15 flex items-center justify-center space-x-2 transition duration-200 shrink-0 text-sm"
        >
          <Plus size={18} className="stroke-[2.5]" />
          <span>Tambah Pembagian Jam</span>
        </button>
      </div>

      {/* Filter and Search Section */}
      <div className="bg-white p-5 rounded-xl shadow-xs border border-slate-200 space-y-4">
        <div className="flex items-center space-x-2 border-b border-slate-100 pb-2">
          <SlidersHorizontal size={14} className="text-slate-400" />
          <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider">Penyaringan Distribusi</h3>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {/* Filter Guru */}
          <div>
            <label className="block text-xs font-semibold text-slate-500 mb-1">Pilih Guru</label>
            <select
              value={filterTeacher}
              onChange={(e) => setFilterTeacher(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-700 focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500 font-medium"
            >
              <option value="">-- Semua Guru --</option>
              {teachers.map(t => (
                <option key={t.id} value={t.id}>{t.name}</option>
              ))}
            </select>
          </div>

          {/* Filter Mapel */}
          <div>
            <label className="block text-xs font-semibold text-slate-500 mb-1">Pilih Mapel</label>
            <select
              value={filterSubject}
              onChange={(e) => setFilterSubject(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-700 focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500 font-medium"
            >
              <option value="">-- Semua Mapel --</option>
              {subjects.map(s => (
                <option key={s.id} value={s.id}>{s.code} - {s.name}</option>
              ))}
            </select>
          </div>

          {/* Filter Kelas */}
          <div>
            <label className="block text-xs font-semibold text-slate-500 mb-1">Pilih Kelas</label>
            <select
              value={filterClass}
              onChange={(e) => setFilterClass(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-700 focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500 font-medium"
            >
              <option value="">-- Semua Kelas --</option>
              {classes.map(c => (
                <option key={c.id} value={c.id}>{c.name}</option>
              ))}
            </select>
          </div>
        </div>

        {/* Filter Reset */}
        {(filterTeacher || filterSubject || filterClass) && (
          <div className="flex justify-end">
            <button
              onClick={() => {
                setFilterTeacher('');
                setFilterSubject('');
                setFilterClass('');
              }}
              className="text-xs text-red-500 font-semibold hover:underline"
            >
              Bersihkan Filter
            </button>
          </div>
        )}
      </div>

      {/* Main List Table */}
      <div className="bg-white rounded-xl shadow-xs border border-slate-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs md:text-sm">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-slate-500 uppercase font-bold tracking-widest text-[10px]">
                <th className="py-4 px-6">Nama Guru</th>
                <th className="py-4 px-6">Mata Pelajaran</th>
                <th className="py-4 px-6">Kelas</th>
                <th className="py-4 px-6 text-center">Beban Kerja (JP)</th>
                <th className="py-4 px-6 text-right">Aksi</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700">
              {filteredAssignments.length > 0 ? (
                filteredAssignments.map((assign) => {
                  const teacher = teachers.find(t => t.id === assign.teacher_id);
                  const subject = subjects.find(s => s.id === assign.subject_id);
                  const classroom = classes.find(c => c.id === assign.class_id);

                  return (
                    <tr key={assign.id} className="hover:bg-slate-50/20 transition duration-150">
                      <td className="py-4 px-6 font-semibold text-slate-900">
                        {teacher ? teacher.name : 'Unknown Teacher'}
                      </td>
                      <td className="py-4 px-6">
                        <div className="flex flex-col">
                          <span className="font-semibold text-slate-800">{subject ? subject.name : 'Unknown Subject'}</span>
                          <span className="text-[10px] text-slate-400 font-bold uppercase font-mono">{subject ? subject.code : '-'}</span>
                        </div>
                      </td>
                      <td className="py-4 px-6">
                        <span className="bg-blue-50 text-blue-700 px-2.5 py-0.5 rounded border border-blue-100 font-bold text-xs">
                          {classroom ? classroom.name : 'Unknown Class'}
                        </span>
                      </td>
                      <td className="py-4 px-6 text-center font-mono font-bold text-slate-900 text-base">
                        {assign.hours_per_week} <span className="text-xs font-semibold text-slate-400">JP</span>
                      </td>
                      <td className="py-4 px-6 text-right">
                        <div className="flex items-center justify-end space-x-2">
                          <button
                            onClick={() => openEditModal(assign)}
                            className="p-1.5 hover:bg-slate-100 rounded-lg text-slate-500 hover:text-slate-900 transition"
                            title="Edit Distribusi"
                          >
                            <Edit size={15} />
                          </button>
                          <button
                            onClick={() => handleDelete(
                              assign.id, 
                              teacher?.name || '', 
                              subject?.name || '', 
                              classroom?.name || ''
                            )}
                            className="p-1.5 hover:bg-red-50 rounded-lg text-slate-400 hover:text-red-500 transition"
                            title="Hapus Distribusi"
                          >
                            <Trash2 size={15} />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              ) : (
                <tr>
                  <td colSpan={5} className="py-12 text-center text-slate-400 font-medium">
                    Tidak ada data pembagian jam mengajar yang sesuai dengan filter.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Form Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-slate-950/40 backdrop-blur-xs flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl w-full max-w-lg shadow-2xl border border-slate-100 overflow-hidden animate-zoom-in">
            {/* Modal Header */}
            <div className="px-6 py-5 border-b border-slate-100 flex justify-between items-center bg-slate-50">
              <h2 className="font-display font-bold text-lg text-slate-900">
                {editingId ? 'Edit Pembagian Jam' : 'Atur Pembagian Jam Mengajar'}
              </h2>
              <button 
                onClick={() => setIsModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 hover:bg-slate-200/50 p-1.5 rounded-lg transition"
              >
                <X size={18} />
              </button>
            </div>

            {/* Modal Body / Form */}
            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              {/* Info Akademik */}
              <div className="bg-blue-50 p-3 rounded-xl border border-blue-100 flex items-center space-x-2 text-xs font-semibold text-blue-800">
                <CalendarClock size={16} />
                <span>
                  Penugasan untuk Tahun Pelajaran: {academicSettings.academic_year} (Semester {academicSettings.semester})
                </span>
              </div>

              {/* Error Message */}
              {errorMsg && (
                <div className="bg-red-50 text-red-700 text-xs p-3.5 rounded-xl border border-red-100 flex items-center justify-between font-medium">
                  <span>{errorMsg}</span>
                  <button 
                    type="button" 
                    onClick={() => setErrorMsg(null)}
                    className="text-red-400 hover:text-red-600 transition p-1 rounded"
                  >
                    <X size={14} className="stroke-[2.5]" />
                  </button>
                </div>
              )}

              {/* Guru Selector */}
              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1.5">Pilih Guru Pendidik</label>
                <select
                  required
                  value={formData.teacher_id}
                  onChange={(e) => setFormData({...formData, teacher_id: e.target.value})}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2.5 text-sm text-slate-850 focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500 transition font-medium text-slate-800"
                >
                  <option value="" disabled>-- Pilih Guru --</option>
                  {teachers.map(t => (
                    <option key={t.id} value={t.id}>
                      {t.name} (Spesialisasi: {t.bidang_studi})
                    </option>
                  ))}
                </select>
              </div>

              {/* Mapel Selector */}
              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1.5">Pilih Mata Pelajaran</label>
                <select
                  required
                  value={formData.subject_id}
                  onChange={(e) => setFormData({...formData, subject_id: e.target.value})}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2.5 text-sm text-slate-850 focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500 transition font-medium text-slate-800"
                >
                  <option value="" disabled>-- Pilih Mapel --</option>
                  {subjects.map(s => (
                    <option key={s.id} value={s.id}>
                      [{s.code}] {s.name} ({s.kurikulum})
                    </option>
                  ))}
                </select>
              </div>

              {/* Kelas Selector */}
              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1.5">Pilih Rombongan Belajar (Kelas)</label>
                <select
                  required
                  value={formData.class_id}
                  onChange={(e) => setFormData({...formData, class_id: e.target.value})}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2.5 text-sm text-slate-850 focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500 transition font-medium text-slate-800"
                >
                  <option value="" disabled>-- Pilih Kelas --</option>
                  {classes.map(c => (
                    <option key={c.id} value={c.id}>
                      {c.name} (Tingkat {c.tingkat})
                    </option>
                  ))}
                </select>
              </div>

              {/* Hours per Week */}
              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1.5">Beban Jam Pelajaran Per Minggu (JP)</label>
                <div className="flex items-center space-x-3">
                  <input
                    type="number"
                    min="0"
                    max="100"
                    required
                    value={formData.hours_per_week}
                    onChange={(e) => setFormData({...formData, hours_per_week: parseInt(e.target.value) || 0})}
                    className="w-28 bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 text-sm text-slate-800 font-bold font-mono focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500 transition text-center"
                  />
                  <span className="text-sm font-semibold text-slate-500">Jam Pelajaran (JP) / Minggu</span>
                </div>
              </div>

              {/* Modal Footer Buttons */}
              <div className="pt-4 border-t border-slate-100 flex justify-end space-x-2.5">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 rounded-xl text-xs font-semibold text-slate-600 transition"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-blue-600 hover:bg-blue-700 rounded-xl text-xs font-bold text-white shadow-md shadow-blue-600/10 transition"
                >
                  {editingId ? 'Simpan Perubahan' : 'Tugaskan Mengajar'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
