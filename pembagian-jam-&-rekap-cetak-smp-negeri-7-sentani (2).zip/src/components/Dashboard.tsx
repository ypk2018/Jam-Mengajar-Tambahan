/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { 
  Users, 
  BookOpen, 
  School, 
  Clock, 
  AlertTriangle, 
  CheckCircle2, 
  ArrowUpRight 
} from 'lucide-react';
import { Teacher, Subject, ClassRoom, TeachingAssignment, AdditionalTask, AcademicSettings } from '../types';

interface DashboardProps {
  teachers: Teacher[];
  subjects: Subject[];
  classes: ClassRoom[];
  assignments: TeachingAssignment[];
  additionalTasks: AdditionalTask[];
  academicSettings: AcademicSettings;
}

export default function Dashboard({
  teachers,
  subjects,
  classes,
  assignments,
  additionalTasks,
  academicSettings
}: DashboardProps) {
  // Filter assignments based on current year and semester
  const currentAssignments = assignments.filter(
    a => a.academic_year === academicSettings.academic_year && a.semester === academicSettings.semester
  );

  const currentTasks = additionalTasks.filter(
    t => t.academic_year === academicSettings.academic_year
  );

  // Total hours calculation
  const totalWeeklyHours = currentAssignments.reduce((acc, curr) => acc + curr.hours_per_week, 0);

  // Get total teaching hours & task hours for each teacher
  const teacherStats = teachers.map(teacher => {
    // Teaching hours
    const teachingHours = currentAssignments
      .filter(a => a.teacher_id === teacher.id)
      .reduce((acc, curr) => acc + curr.hours_per_week, 0);

    // Additional task hours
    const taskHours = currentTasks
      .filter(t => t.teacher_id === teacher.id)
      .reduce((acc, curr) => acc + curr.hours_equivalent, 0);

    const totalHours = teachingHours + taskHours;

    // Load category based on Indonesian regulation (Minimum 18-24 JP is optimal)
    let category: 'under' | 'optimal' | 'over' = 'optimal';
    if (totalHours < 18) {
      category = 'under';
    } else if (totalHours > 24) {
      category = 'over';
    }

    return {
      ...teacher,
      teachingHours,
      taskHours,
      totalHours,
      category
    };
  });

  // Calculate distributions
  const underCount = teacherStats.filter(t => t.category === 'under').length;
  const optimalCount = teacherStats.filter(t => t.category === 'optimal').length;
  const overCount = teacherStats.filter(t => t.category === 'over').length;

  // Subject details with hours
  const subjectStats = subjects.map(subject => {
    const hours = currentAssignments
      .filter(a => a.subject_id === subject.id)
      .reduce((acc, curr) => acc + curr.hours_per_week, 0);
    const classCount = currentAssignments
      .filter(a => a.subject_id === subject.id).length;

    return {
      ...subject,
      hours,
      classCount
    };
  }).sort((a, b) => b.hours - a.hours);

  return (
    <div className="space-y-8 animate-fade-in">
      {/* Page Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <span className="text-blue-600 font-semibold text-xs uppercase tracking-wider">Ringkasan Sistem</span>
          <h1 className="font-display font-bold text-3xl text-slate-950 tracking-tight mt-1">Dashboard Kinerja Guru</h1>
          <p className="text-slate-500 text-sm mt-1">SMP Negeri 7 Sentani • Tahun Pelajaran {academicSettings.academic_year} (Semester {academicSettings.semester})</p>
        </div>
      </div>

      {/* KPI Bento Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {/* KPI 1 */}
        <div id="kpi-teachers" className="bg-white p-6 rounded-xl shadow-xs border border-slate-200 flex items-center justify-between transition hover:shadow-md">
          <div>
            <p className="text-slate-500 font-semibold text-xs tracking-wide uppercase">Total Guru</p>
            <h3 className="font-display font-bold text-3xl text-slate-800 mt-2">{teachers.length}</h3>
            <span className="text-xs text-slate-550 block mt-1 font-medium">Staf Pendidik Aktif</span>
          </div>
          <div className="bg-blue-50 text-blue-600 p-4 rounded-xl">
            <Users size={24} className="stroke-[2]" />
          </div>
        </div>

        {/* KPI 2 */}
        <div id="kpi-subjects" className="bg-white p-6 rounded-xl shadow-xs border border-slate-200 flex items-center justify-between transition hover:shadow-md">
          <div>
            <p className="text-slate-500 font-semibold text-xs tracking-wide uppercase">Mata Pelajaran</p>
            <h3 className="font-display font-bold text-3xl text-slate-800 mt-2">{subjects.length}</h3>
            <span className="text-xs text-slate-550 block mt-1 font-medium">Mapel Terdaftar</span>
          </div>
          <div className="bg-blue-50 text-blue-600 p-4 rounded-xl">
            <BookOpen size={24} className="stroke-[2]" />
          </div>
        </div>

        {/* KPI 3 */}
        <div id="kpi-classes" className="bg-white p-6 rounded-xl shadow-xs border border-slate-200 flex items-center justify-between transition hover:shadow-md">
          <div>
            <p className="text-slate-500 font-semibold text-xs tracking-wide uppercase">Rombongan Belajar</p>
            <h3 className="font-display font-bold text-3xl text-slate-800 mt-2">{classes.length}</h3>
            <span className="text-xs text-slate-550 block mt-1 font-medium">Kelas VII, VIII, IX</span>
          </div>
          <div className="bg-blue-50 text-blue-600 p-4 rounded-xl">
            <School size={24} className="stroke-[2]" />
          </div>
        </div>

        {/* KPI 4 */}
        <div id="kpi-hours" className="bg-white p-6 rounded-xl shadow-xs border border-slate-200 flex items-center justify-between transition hover:shadow-md">
          <div>
            <p className="text-slate-500 font-semibold text-xs tracking-wide uppercase">Total Jam Terbagi</p>
            <h3 className="font-display font-bold text-3xl text-slate-800 mt-2">{totalWeeklyHours} JP</h3>
            <span className="text-xs text-slate-550 block mt-1 font-medium">Jam Pelajaran / Minggu</span>
          </div>
          <div className="bg-blue-50 text-blue-600 p-4 rounded-xl">
            <Clock size={24} className="stroke-[2]" />
          </div>
        </div>
      </div>

      {/* Main Analysis Blocks */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Workload Categories Status */}
        <div className="bg-white p-6 rounded-xl shadow-xs border border-slate-200 lg:col-span-1 space-y-6">
          <h2 className="font-display font-bold text-lg text-slate-900 border-b border-slate-100 pb-4">Status Beban Kerja Guru</h2>
          
          <div className="space-y-4">
            {/* Optimal */}
            <div className="p-4 rounded-xl bg-white border border-slate-200 flex items-center justify-between shadow-2xs">
              <div className="flex items-center space-x-3">
                <div className="bg-green-600 text-white p-1.5 rounded-lg">
                  <CheckCircle2 size={16} />
                </div>
                <div>
                  <h4 className="font-semibold text-sm text-slate-900">Optimal (18 - 24 JP)</h4>
                  <p className="text-xs text-slate-500">Sesuai regulasi Kemendikbud</p>
                </div>
              </div>
              <span className="font-display font-bold text-xl text-green-700">{optimalCount} Guru</span>
            </div>

            {/* Underloaded */}
            <div className="p-4 rounded-xl bg-white border border-slate-200 flex items-center justify-between shadow-2xs">
              <div className="flex items-center space-x-3">
                <div className="bg-yellow-500 text-white p-1.5 rounded-lg">
                  <AlertTriangle size={16} />
                </div>
                <div>
                  <h4 className="font-semibold text-sm text-slate-900">Kurang (&lt; 18 JP)</h4>
                  <p className="text-xs text-slate-500">Beban mengajar kurang</p>
                </div>
              </div>
              <span className="font-display font-bold text-xl text-yellow-700">{underCount} Guru</span>
            </div>

            {/* Overloaded */}
            <div className="p-4 rounded-xl bg-white border border-slate-200 flex items-center justify-between shadow-2xs">
              <div className="flex items-center space-x-3">
                <div className="bg-red-500 text-white p-1.5 rounded-lg">
                  <AlertTriangle size={16} />
                </div>
                <div>
                  <h4 className="font-semibold text-sm text-slate-900">Berlebih (&gt; 24 JP)</h4>
                  <p className="text-xs text-slate-550">Kelebihan beban mengajar</p>
                </div>
              </div>
              <span className="font-display font-bold text-xl text-red-600">{overCount} Guru</span>
            </div>
          </div>

          {/* Quick Explanation */}
          <div className="text-xs text-slate-500 leading-relaxed bg-slate-50 p-4 rounded-xl border border-slate-100">
            <strong>Catatan Regulasi:</strong> Setiap Guru diwajibkan mengajar minimal 18 JP dan maksimal 24 JP per minggu untuk pemenuhan sertifikasi pendidik. Tugas Tambahan dihitung setara JP mengajar (misal: Kepala Sekolah = 12 JP, Wakasek = 12 JP, Wali Kelas = 6 JP).
          </div>
        </div>

        {/* Top Teachers Workload List */}
        <div className="bg-white p-6 rounded-xl shadow-xs border border-slate-200 lg:col-span-2 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-4">
            <h2 className="font-display font-bold text-lg text-slate-900">Rincian Jam Kerja Guru</h2>
            <span className="text-xs font-semibold text-slate-400 bg-slate-50 px-2.5 py-1 rounded-md">Urut Berdasarkan JP</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-slate-600">
              <thead>
                <tr className="border-b border-slate-200 text-slate-500 uppercase tracking-widest font-bold text-[10px]">
                  <th className="py-3 px-2">Nama Guru</th>
                  <th className="py-3 px-2">Status</th>
                  <th className="py-3 px-2 text-center">Jam Mengajar</th>
                  <th className="py-3 px-2 text-center">Tugas Tambahan</th>
                  <th className="py-3 px-2 text-center">Total JP</th>
                  <th className="py-3 px-2 text-right">Kategori</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {teacherStats.map((teacher) => (
                  <tr key={teacher.id} className="hover:bg-slate-50/40 transition">
                    <td className="py-3.5 px-2 font-semibold text-slate-800">{teacher.name}</td>
                    <td className="py-3.5 px-2">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        teacher.status === 'PNS' ? 'bg-blue-50 text-blue-700 border border-blue-100' :
                        teacher.status === 'PPPK' ? 'bg-cyan-50 text-cyan-700 border border-cyan-100' :
                        'bg-slate-100 text-slate-600'
                      }`}>
                        {teacher.status}
                      </span>
                    </td>
                    <td className="py-3.5 px-2 text-center font-mono font-medium">{teacher.teachingHours} JP</td>
                    <td className="py-3.5 px-2 text-center font-mono font-medium text-slate-500">{teacher.taskHours} JP</td>
                    <td className="py-3.5 px-2 text-center font-mono font-bold text-slate-950">{teacher.totalHours} JP</td>
                    <td className="py-3.5 px-2 text-right">
                      <span className={`inline-flex items-center space-x-1 px-2.5 py-0.5 rounded-full font-bold text-[10px] ${
                        teacher.category === 'optimal' ? 'bg-green-100 text-green-700' :
                        teacher.category === 'under' ? 'bg-yellow-100 text-yellow-700' :
                        'bg-red-100 text-red-700'
                      }`}>
                        {teacher.category === 'optimal' ? 'Optimal' :
                         teacher.category === 'under' ? 'Kurang' : 'Berlebih'}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Subject Distribution Stats */}
      <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs">
        <h2 className="font-display font-bold text-lg text-slate-900 border-b border-slate-100 pb-4 mb-6">Distribusi Jam per Mata Pelajaran</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-4">
          {subjectStats.map((sub) => (
            <div key={sub.id} className="p-4 rounded-xl border border-slate-200 bg-slate-50/50 flex flex-col justify-between transition hover:border-slate-300">
              <div>
                <span className="font-mono text-[10px] font-bold text-slate-500 bg-slate-200 px-2 py-0.5 rounded">
                  {sub.code}
                </span>
                <h4 className="font-bold text-slate-800 text-xs mt-2.5 leading-tight line-clamp-1">
                  {sub.name}
                </h4>
                <p className="text-[10px] text-slate-400 mt-1 font-medium">{sub.kurikulum}</p>
              </div>
              <div className="mt-4 pt-3 border-t border-slate-100 flex justify-between items-center text-slate-500">
                <span className="text-[10px] font-semibold">{sub.classCount} Kelas</span>
                <span className="font-mono font-bold text-slate-800 text-sm">{sub.hours} JP</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
